import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface CloudMailinPayload {
  headers: {
    subject?: string;
    from?: string;
    to?: string;
  };
  envelope: {
    from?: string;
    to?: string[];
  };
  plain?: string;
  html?: string;
  attachments?: Array<{
    file_name?: string;
    content?: string;
    content_type?: string;
  }>;
  [key: string]: any;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const payload: CloudMailinPayload = await req.json();

    console.log("Received email:", {
      from: payload.envelope?.from || payload.headers?.from,
      subject: payload.headers?.subject,
      receivedAt: new Date().toISOString()
    });

    const emailData = {
      received_at: new Date().toISOString(),
      subject: payload.headers?.subject || "",
      from_email: payload.envelope?.from || payload.headers?.from || "",
      to_email: payload.envelope?.to?.[0] || payload.headers?.to || "",
      body_plain: payload.plain || "",
      body_html: payload.html || null,
      raw_json: payload,
    };

    const { data, error } = await supabase
      .from("raw_emails")
      .insert(emailData)
      .select()
      .single();

    if (error) {
      console.error("Database error:", error);
      return new Response(
        JSON.stringify({ success: false, error: error.message }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    console.log("Email stored successfully:", data.id);

    let slpProcessed = false;
    let slpStats = null;
    let logbookProcessed = false;
    let feedbackProcessed = false;
    let feedbackStats = null;

    if (payload.headers?.subject?.includes("Daily review report")) {
      try {
        console.log("Detected guest feedback email, processing...");

        const feedbackResponse = await fetch(`${supabaseUrl}/functions/v1/process-guest-feedback`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            emailId: data.id
          })
        });

        const feedbackResult = await feedbackResponse.json();

        if (feedbackResult.success) {
          console.log("Guest feedback processed successfully:", feedbackResult.count, "reviews");
          feedbackProcessed = true;
          feedbackStats = { count: feedbackResult.count };
        } else {
          console.error("Failed to process guest feedback:", feedbackResult.error);
        }
      } catch (feedbackError) {
        console.error("Error processing guest feedback:", feedbackError);
      }
    }

    if (payload.headers?.subject?.includes("Daily Logbook Summary")) {
      try {
        console.log("Detected Daily Logbook email, processing...");

        const logbookResponse = await fetch(`${supabaseUrl}/functions/v1/process-daily-logbook`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            emailId: data.id
          })
        });

        const logbookResult = await logbookResponse.json();

        if (logbookResult.success) {
          console.log("Daily Logbook processed successfully");
          logbookProcessed = true;
        } else {
          console.error("Failed to process Daily Logbook:", logbookResult.error);
        }
      } catch (logbookError) {
        console.error("Error processing Daily Logbook:", logbookError);
      }
    }

    if (payload.attachments && payload.attachments.length > 0) {
      const slpAttachment = payload.attachments.find(
        att => {
          const fileName = att.file_name?.toLowerCase() || '';
          const contentType = att.content_type?.toLowerCase() || '';
          const isDataFile = (fileName.endsWith('.csv') && contentType.includes('csv')) ||
                 (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) ||
                 contentType.includes('spreadsheet') ||
                 contentType.includes('excel');
          const isNotImage = !contentType.includes('image') && !fileName.match(/\.(png|jpg|jpeg|gif|bmp)$/i);
          return isDataFile && isNotImage;
        }
      );

      if (slpAttachment && slpAttachment.content) {
        try {
          const fileName = slpAttachment.file_name?.toLowerCase() || '';
          const isExcel = fileName.endsWith('.xlsx') || fileName.endsWith('.xls') ||
                          slpAttachment.content_type?.includes('spreadsheet') ||
                          slpAttachment.content_type?.includes('excel');

          console.log(`Found ${isExcel ? 'Excel' : 'CSV'} attachment, processing SLP data...`);

          const slpResponse = await fetch(`${supabaseUrl}/functions/v1/process-slp-attachment`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${supabaseKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              fileContent: slpAttachment.content,
              fileType: isExcel ? 'excel' : 'csv'
            })
          });

          const slpResult = await slpResponse.json();

          if (slpResult.success) {
            console.log("SLP data processed successfully:", slpResult.stats);
            slpProcessed = true;
            slpStats = slpResult.stats;
          } else {
            console.error("Failed to process SLP data:", slpResult.error);
          }
        } catch (slpError) {
          console.error("Error processing SLP attachment:", slpError);
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        id: data.id,
        slpProcessed,
        slpStats,
        logbookProcessed,
        feedbackProcessed,
        feedbackStats
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error processing email:", error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
