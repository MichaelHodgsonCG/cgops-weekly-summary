import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import { Document, Packer, Paragraph, Table, TableRow, TableCell, TextRun, WidthType, AlignmentType, BorderStyle, VerticalAlign, HeadingLevel, ShadingType } from 'npm:docx@8.5.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface RequestBody {
  fiscalYear: number;
  period: number;
  week: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const body: RequestBody = await req.json();
    const { fiscalYear, period, week } = body;

    const { data: fiscalData } = await supabase
      .from('fiscal_calendar')
      .select('end_date')
      .eq('fiscal_year', fiscalYear)
      .eq('period', period)
      .eq('week', week)
      .single();

    if (!fiscalData) {
      throw new Error('Fiscal calendar entry not found');
    }

    const weekEndingDate = fiscalData.end_date;

    const { data: restaurants } = await supabase
      .from('weekly_chef_summary')
      .select('*, locations!inner(*)')
      .eq('fiscal_year', fiscalYear)
      .eq('period_number', period)
      .eq('week_number', week)
      .eq('locations.exclude_from_reporting', false)
      .order('locations(code)');

    if (!restaurants || restaurants.length === 0) {
      throw new Error('No data available for this period');
    }

    const { data: journals } = await supabase
      .from('weekly_chef_summary')
      .select('id, locations!inner(name), notes, hiring_notes, tm_mots_of_note, food_cost_summary, labour_summary, boh_promo_summary, action_plan_summary, ai_summary')
      .eq('fiscal_year', fiscalYear)
      .eq('period_number', period)
      .eq('week_number', week)
      .eq('locations.exclude_from_reporting', false)
      .order('locations(code)');

    const { data: plData } = await supabase
      .from('pl_line_items')
      .select('*, locations!inner(*)')
      .eq('week_ending_date', weekEndingDate)
      .eq('locations.exclude_from_reporting', false)
      .order('locations(code)');

    const docBuffer = await generateDocx(fiscalYear, period, week, restaurants, journals || [], plData || [], weekEndingDate);

    return new Response(docBuffer, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="executive-report-fy${fiscalYear}-p${period}-w${week}.docx"`,
      },
    });
  } catch (error) {
    console.error('Error exporting report:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

async function generateDocx(fiscalYear: number, period: number, week: number, restaurants: any[], journals: any[], plData: any[], weekEndingDate: string): Promise<Uint8Array> {
  const formatCurrency = (value: number) => `$${Math.round(value).toLocaleString()}`;
  const formatPercent = (value: number) => `${value.toFixed(2)}%`;

  const formatVarianceCellValue = (value: number) => {
    const sign = value >= 0 ? '+' : '';
    return `${sign}${formatCurrency(value)}`;
  };

  const parseTimeToMinutes = (timeStr: string): { hours: number; minutes: number } | null => {
    if (!timeStr) return null;
    const match = timeStr.match(/(\d+):(\d+)/);
    if (match) {
      return {
        hours: parseInt(match[1]),
        minutes: parseInt(match[2])
      };
    }
    return null;
  };

  const shouldHighlightTime = (timeStr: string, restaurantCode: string, isBrunchTime: boolean = false): boolean => {
    const time = parseTimeToMinutes(timeStr);
    if (time === null) return false;

    if (isBrunchTime) {
      return time.hours > 10 || (time.hours === 10 && time.minutes > 0);
    }

    if (restaurantCode === 'BTBA' || restaurantCode === 'SKT') {
      return time.hours >= 10;
    }
    return time.hours >= 12;
  };

  const shouldHighlightPromo = (promoAmount: number, weekSales: number): boolean => {
    if (weekSales === 0) return false;
    const promoPercent = (promoAmount / weekSales) * 100;
    return promoPercent > 0.25;
  };

  const getLineItemValue = (locationId: string, lineItemName: string, field: 'current_actual' | 'current_budget' | 'current_actual_pct' | 'current_budget_pct' | 'ytd_actual' | 'ytd_budget' | 'ytd_actual_pct' | 'ytd_budget_pct'): number => {
    const item = plData.find(pl => pl.location_id === locationId && pl.line_item_name === lineItemName);
    return item ? (parseFloat(item[field]) || 0) : 0;
  };

  const calculateConsolidatedMetrics = (locationCodes: string[]) => {
    const filteredPL = plData.filter(pl => locationCodes.includes(pl.locations.code));
    const locationIds = [...new Set(filteredPL.map(pl => pl.location_id))];

    const totalPTDSales = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Food Sales', 'current_actual'), 0);
    const totalPTDBudget = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Food Sales', 'current_budget'), 0);
    const totalPTDSalesVariance = totalPTDSales - totalPTDBudget;

    const totalYTDSales = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Food Sales', 'ytd_actual'), 0);
    const totalYTDBudget = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Food Sales', 'ytd_budget'), 0);
    const totalYTDSalesVariance = totalYTDSales - totalYTDBudget;

    const totalWeekSales = totalPTDSales;
    const totalWeekSalesVariance = totalPTDSalesVariance;

    const totalPTDFoodCost = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Cost of Sales (Food)', 'current_actual'), 0);
    const ptdFoodCostPct = totalPTDSales > 0 ? (totalPTDFoodCost / totalPTDSales) * 100 : 0;
    const totalPTDBudgetFoodCost = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Cost of Sales (Food)', 'current_budget'), 0);
    const ptdBudgetFoodCostPct = totalPTDBudget > 0 ? (totalPTDBudgetFoodCost / totalPTDBudget) * 100 : 0;
    const ptdFoodCostVariancePts = ptdFoodCostPct - ptdBudgetFoodCostPct;

    const totalYTDFoodCost = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Cost of Sales (Food)', 'ytd_actual'), 0);
    const ytdFoodCostPct = totalYTDSales > 0 ? (totalYTDFoodCost / totalYTDSales) * 100 : 0;
    const totalYTDBudgetFoodCost = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Cost of Sales (Food)', 'ytd_budget'), 0);
    const ytdBudgetFoodCostPct = totalYTDBudget > 0 ? (totalYTDBudgetFoodCost / totalYTDBudget) * 100 : 0;
    const ytdFoodCostVariancePts = ytdFoodCostPct - ytdBudgetFoodCostPct;

    const weekFoodCostPct = ptdFoodCostPct;
    const weekFoodCostVariancePts = ptdFoodCostVariancePts;

    const totalPTDLabour = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Kitchen Labour', 'current_actual'), 0);
    const ptdLabourPct = totalPTDSales > 0 ? (totalPTDLabour / totalPTDSales) * 100 : 0;
    const totalPTDBudgetLabour = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Kitchen Labour', 'current_budget'), 0);
    const ptdBudgetLabourPct = totalPTDBudget > 0 ? (totalPTDBudgetLabour / totalPTDBudget) * 100 : 0;
    const ptdLabourVariancePts = ptdLabourPct - ptdBudgetLabourPct;

    const totalYTDLabour = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Kitchen Labour', 'ytd_actual'), 0);
    const ytdLabourPct = totalYTDSales > 0 ? (totalYTDLabour / totalYTDSales) * 100 : 0;
    const totalYTDBudgetLabour = locationIds.reduce((sum, locId) => sum + getLineItemValue(locId, 'Kitchen Labour', 'ytd_budget'), 0);
    const ytdBudgetLabourPct = totalYTDBudget > 0 ? (totalYTDBudgetLabour / totalYTDBudget) * 100 : 0;
    const ytdLabourVariancePts = ytdLabourPct - ytdBudgetLabourPct;

    const weekLabourPct = ptdLabourPct;
    const weekLabourVariancePts = ptdLabourVariancePts;

    return {
      totalWeekSales,
      totalWeekSalesVariance,
      totalPTDSales,
      totalPTDSalesVariance,
      totalYTDSales,
      totalYTDSalesVariance,
      weekFoodCostPct,
      weekFoodCostVariancePts,
      ptdFoodCostPct,
      ptdFoodCostVariancePts,
      ytdFoodCostPct,
      ytdFoodCostVariancePts,
      weekLabourPct,
      weekLabourVariancePts,
      ptdLabourPct,
      ptdLabourVariancePts,
      ytdLabourPct,
      ytdLabourVariancePts
    };
  };

  const allLocationCodes = [...new Set(plData.map(pl => pl.locations.code))];
  const allRestaurants = calculateConsolidatedMetrics(allLocationCodes);

  const beertownSociableCodes = allLocationCodes.filter(code => code.startsWith('BT') || code === 'SKT');
  const beertownSociableMetrics = calculateConsolidatedMetrics(beertownSociableCodes);

  const trinityCodes = allLocationCodes.filter(code => ['WC', 'TBK', 'SOLE'].includes(code));
  const trinityMetrics = calculateConsolidatedMetrics(trinityCodes);

  const formatConsolidatedLine = (label: string, metrics: ReturnType<typeof calculateConsolidatedMetrics>) => {
    const formatCurr = (val: number) => `$${Math.round(val).toLocaleString()}`;
    const formatVar = (val: number) => {
      const sign = val >= 0 ? '+' : '';
      return `(${sign}${formatCurr(val)})`;
    };
    const formatPts = (val: number) => {
      const sign = val >= 0 ? '+' : '';
      return `(${sign}${val.toFixed(2)} pts)`;
    };

    return [
      `${label}`,
      `Food Sales: Week ${formatCurr(metrics.totalWeekSales)} ${formatVar(metrics.totalWeekSalesVariance)} | PTD ${formatCurr(metrics.totalPTDSales)} ${formatVar(metrics.totalPTDSalesVariance)} | YTD ${formatCurr(metrics.totalYTDSales)} ${formatVar(metrics.totalYTDSalesVariance)}`,
      `COGS (Food): Week ${metrics.weekFoodCostPct.toFixed(2)}% ${formatPts(metrics.weekFoodCostVariancePts)} | PTD ${metrics.ptdFoodCostPct.toFixed(2)}% ${formatPts(metrics.ptdFoodCostVariancePts)} | YTD ${metrics.ytdFoodCostPct.toFixed(2)}% ${formatPts(metrics.ytdFoodCostVariancePts)}`,
      `Labour: Week ${metrics.weekLabourPct.toFixed(2)}% ${formatPts(metrics.weekLabourVariancePts)} | PTD ${metrics.ptdLabourPct.toFixed(2)}% ${formatPts(metrics.ptdLabourVariancePts)} | YTD ${metrics.ytdLabourPct.toFixed(2)}% ${formatPts(metrics.ytdLabourVariancePts)}`
    ];
  };

  const restaurantMetrics = restaurants.map(current => {
    const weekSales = getLineItemValue(current.location_id, 'Food Sales', 'current_actual');
    const weekBudget = getLineItemValue(current.location_id, 'Food Sales', 'current_budget');
    const weekSalesVariance = weekSales - weekBudget;
    const qtdSales = getLineItemValue(current.location_id, 'Food Sales', 'ytd_actual');
    const qtdBudget = getLineItemValue(current.location_id, 'Food Sales', 'ytd_budget');
    const qtdSalesVariance = qtdSales - qtdBudget;

    const weekFoodCost = current.actual_food_cost_pct || 0;
    const weekBudgetFoodCost = current.budget_food_cost_pct || 0;
    const weekFoodCostVariance = weekFoodCost - weekBudgetFoodCost;
    const weekFoodCostVarianceDollar = (weekSales * weekFoodCostVariance) / 100;

    const ptdFoodCost = current.food_cost_ptd_pct || 0;
    const ptdBudgetFoodCost = current.budget_food_cost_pct || 0;
    const ptdFoodCostVariance = ptdFoodCost - ptdBudgetFoodCost;
    const ptdFoodCostVarianceDollar = (qtdSales * ptdFoodCostVariance) / 100;

    const weekLabour = current.labour_cost_pct || 0;
    const weekBudgetLabour = current.labour_budget_pct || 0;
    const weekLabourVariance = weekLabour - weekBudgetLabour;
    const weekLabourVarianceDollar = (weekSales * weekLabourVariance) / 100;

    const ptdLabour = current.labour_cost_ptd_pct || 0;
    const ptdBudgetLabour = current.labour_budget_pct || 0;
    const ptdLabourVariance = ptdLabour - ptdBudgetLabour;
    const ptdLabourVarianceDollar = (qtdSales * ptdLabourVariance) / 100;

    const weekTheoreticalFoodCost = current.theoretical_food_cost_pct || 0;
    const weekTheoreticalVariance = weekFoodCost - weekTheoreticalFoodCost;
    const weekTheoreticalVarianceDollar = (weekSales * weekTheoreticalVariance) / 100;
    const ptdTheoreticalVarianceDollar = (qtdSales * weekTheoreticalVariance) / 100;

    const weekPromo = current.boh_promo_amount || 0;
    const ptdPromo = current.promo_ptd || 0;
    const expoTime = current.qsr_expo_time || '';
    const brunchTime = current.qsr_weekend_lunch_time || '';

    return {
      name: current.locations.name,
      code: current.locations.code,
      weekSales,
      weekSalesVariance,
      qtdSales,
      qtdSalesVariance,
      weekFoodCost,
      weekFoodCostVariance,
      weekFoodCostVarianceDollar,
      ptdFoodCost,
      ptdFoodCostVariance,
      ptdFoodCostVarianceDollar,
      weekTheoreticalVarianceDollar,
      ptdTheoreticalVarianceDollar,
      weekLabour,
      weekLabourVariance,
      weekLabourVarianceDollar,
      ptdLabour,
      ptdLabourVariance,
      ptdLabourVarianceDollar,
      weekPromo,
      ptdPromo,
      expoTime,
      brunchTime,
      aiSummary: current.ai_summary
    };
  });

  const columnWidth = 720;
  const metricRows = [
    { label: 'Food Cost +/- Budget $ Week', values: restaurantMetrics.map(r => ({ value: formatVarianceCellValue(r.weekFoodCostVarianceDollar), isNegative: r.weekFoodCostVarianceDollar > 0 })) },
    { label: 'Food Cost +/- Budget $ Period', values: restaurantMetrics.map(r => ({ value: formatVarianceCellValue(r.ptdFoodCostVarianceDollar), isNegative: r.ptdFoodCostVarianceDollar > 0 })) },
    { label: 'Food Cost vs Theoretical $ Week', values: restaurantMetrics.map(r => ({ value: formatVarianceCellValue(r.weekTheoreticalVarianceDollar), isNegative: r.weekTheoreticalVarianceDollar > 0 })) },
    { label: 'Food Cost vs Theoretical $ Period', values: restaurantMetrics.map(r => ({ value: formatVarianceCellValue(r.ptdTheoreticalVarianceDollar), isNegative: r.ptdTheoreticalVarianceDollar > 0 })) },
    { label: 'Labour Cost +/- Budget $ Week', values: restaurantMetrics.map(r => ({ value: formatVarianceCellValue(r.weekLabourVarianceDollar), isNegative: r.weekLabourVarianceDollar > 0 })) },
    { label: 'Labour Cost +/- Budget $ Period', values: restaurantMetrics.map(r => ({ value: formatVarianceCellValue(r.ptdLabourVarianceDollar), isNegative: r.ptdLabourVarianceDollar > 0 })) },
    { label: 'Promos $ Week', values: restaurantMetrics.map(r => ({ value: formatCurrency(r.weekPromo), isNegative: shouldHighlightPromo(r.weekPromo, r.weekSales) })) },
    { label: 'Promos $ Period', values: restaurantMetrics.map(r => ({ value: formatCurrency(r.ptdPromo), isNegative: false })) },
    { label: 'Expo Time', values: restaurantMetrics.map(r => ({ value: r.expoTime, isNegative: shouldHighlightTime(r.expoTime, r.code, false) })) },
    { label: 'Brunch Time', values: restaurantMetrics.map(r => ({ value: r.brunchTime, isNegative: shouldHighlightTime(r.brunchTime, r.code, true) })) },
  ];

  const cgConsolidatedLines = formatConsolidatedLine('CG Consolidated — All Restaurants', allRestaurants);
  const beertownSociableLines = formatConsolidatedLine('Beertown + Sociable', beertownSociableMetrics);
  const trinityLines = formatConsolidatedLine('Trinity (WC/TBK/Sole)', trinityMetrics);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr + 'T00:00:00');
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const sections = [
    new Paragraph({
      text: 'Weekly Executive Report',
      heading: HeadingLevel.HEADING_1,
      spacing: { after: 100 }
    }),
    new Paragraph({
      text: `FY ${fiscalYear} - Period ${period}, Week ${week} (Week Ending ${formatDate(weekEndingDate)})`,
      spacing: { after: 400 }
    }),
    new Paragraph({
      text: 'Budget Variance Summary',
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 0, after: 200 }
    }),
    new Paragraph({
      text: cgConsolidatedLines[0],
      style: 'Strong',
      spacing: { after: 100 }
    }),
    new Paragraph({
      text: cgConsolidatedLines[1],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: cgConsolidatedLines[2],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: cgConsolidatedLines[3],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: cgConsolidatedLines[4],
      spacing: { after: 300 }
    }),
    new Paragraph({
      text: beertownSociableLines[0],
      style: 'Strong',
      spacing: { after: 100 }
    }),
    new Paragraph({
      text: beertownSociableLines[1],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: beertownSociableLines[2],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: beertownSociableLines[3],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: beertownSociableLines[4],
      spacing: { after: 150 }
    }),
    new Paragraph({
      text: trinityLines[0],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: trinityLines[1],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: trinityLines[2],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: trinityLines[3],
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: trinityLines[4],
      spacing: { after: 400 }
    }),
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: [
        new TableRow({
          tableHeader: true,
          children: [
            new TableCell({
              width: { size: 2400, type: WidthType.DXA },
              shading: { fill: 'D3D3D3' },
              children: [new Paragraph({ text: 'Metric', alignment: AlignmentType.LEFT })],
              verticalAlign: VerticalAlign.CENTER
            }),
            ...restaurantMetrics.map(r => new TableCell({
              width: { size: columnWidth, type: WidthType.DXA },
              shading: { fill: 'D3D3D3' },
              children: [new Paragraph({ text: r.code, alignment: AlignmentType.CENTER })],
              verticalAlign: VerticalAlign.CENTER
            }))
          ]
        }),
        ...metricRows.map(row => new TableRow({
          children: [
            new TableCell({
              width: { size: 2400, type: WidthType.DXA },
              shading: { fill: 'F8FAFC', type: ShadingType.SOLID },
              children: [new Paragraph({ text: row.label, alignment: AlignmentType.LEFT })],
              verticalAlign: VerticalAlign.CENTER
            }),
            ...row.values.map(v => new TableCell({
              width: { size: columnWidth, type: WidthType.DXA },
              children: [new Paragraph({
                children: [new TextRun({ text: v.value, color: v.isNegative ? 'DC2626' : '0F172A', bold: v.isNegative })],
                alignment: AlignmentType.CENTER
              })],
              verticalAlign: VerticalAlign.CENTER
            }))
          ]
        }))
      ]
    }),
    new Paragraph({
      text: 'Restaurant Performance',
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 600, after: 200 }
    }),
    ...restaurantMetrics.flatMap(r => [
      new Paragraph({
        text: r.name,
        heading: HeadingLevel.HEADING_3,
        spacing: { before: 300, after: 100 }
      }),
      new Paragraph({
        children: [
          new TextRun({ text: 'Food Sales: ', color: '475569' }),
          new TextRun({ text: `Week ${formatCurrency(r.weekSales)} ` }),
          new TextRun({ text: `(${formatVarianceCellValue(r.weekSalesVariance)})`, color: r.weekSalesVariance < 0 ? 'DC2626' : '0F172A' }),
          new TextRun({ text: ` | QTD ${formatCurrency(r.qtdSales)} ` }),
          new TextRun({ text: `(${formatVarianceCellValue(r.qtdSalesVariance)})`, color: r.qtdSalesVariance < 0 ? 'DC2626' : '0F172A' })
        ],
        spacing: { after: 100 }
      }),
      new Paragraph({
        children: [
          new TextRun({ text: 'Food Cost: ', color: '475569' }),
          new TextRun({ text: `${formatPercent(r.weekFoodCost)} ` }),
          new TextRun({ text: `(${r.weekFoodCostVariance >= 0 ? '+' : ''}${r.weekFoodCostVariance.toFixed(2)} pts)`, color: r.weekFoodCostVariance > 0 ? 'DC2626' : '0F172A' }),
          new TextRun({ text: ` | PTD ${formatPercent(r.ptdFoodCost)} ` }),
          new TextRun({ text: `(${r.ptdFoodCostVariance >= 0 ? '+' : ''}${r.ptdFoodCostVariance.toFixed(2)} pts)`, color: r.ptdFoodCostVariance > 0 ? 'DC2626' : '0F172A' })
        ],
        spacing: { after: 100 }
      }),
      new Paragraph({
        children: [
          new TextRun({ text: 'Labour: ', color: '475569' }),
          new TextRun({ text: `${formatPercent(r.weekLabour)} ` }),
          new TextRun({ text: `(${r.weekLabourVariance >= 0 ? '+' : ''}${r.weekLabourVariance.toFixed(2)} pts)`, color: r.weekLabourVariance > 0 ? 'DC2626' : '0F172A' }),
          new TextRun({ text: ` | PTD ${formatPercent(r.ptdLabour)} ` }),
          new TextRun({ text: `(${r.ptdLabourVariance >= 0 ? '+' : ''}${r.ptdLabourVariance.toFixed(2)} pts)`, color: r.ptdLabourVariance > 0 ? 'DC2626' : '0F172A' })
        ],
        spacing: { after: 200 }
      }),
      ...(r.aiSummary ? [
        new Paragraph({
          text: r.aiSummary,
          spacing: { after: 300 }
        })
      ] : [])
    ])
  ];

  const doc = new Document({
    sections: [{
      properties: {},
      children: sections
    }]
  });

  const buffer = await Packer.toBuffer(doc);
  return new Uint8Array(buffer);
}
