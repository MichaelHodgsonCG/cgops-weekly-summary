import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface RequestBody {
  reportId: string;
  section: string;
  fiscalYear: number;
  period: number;
  week: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const body: RequestBody = await req.json();
    const { reportId, section, fiscalYear, period, week } = body;

    const { data: chefSummaries, error: summariesError } = await supabase
      .from('weekly_chef_summary')
      .select('*, locations!inner(*)')
      .eq('fiscal_year', fiscalYear)
      .eq('period', period)
      .eq('week', week)
      .eq('locations.exclude_from_reporting', false);

    if (summariesError) {
      throw summariesError;
    }

    let content = '';

    switch (section) {
      case 'executive_summary':
        content = generateExecutiveSummary(chefSummaries, fiscalYear, period, week);
        break;
      case 'beertown_summary':
        content = generateBrandSummary(chefSummaries, 'Beertown');
        break;
      case 'trinity_summary':
        content = generateBrandSummary(chefSummaries, 'Trinity');
        break;
      case 'sole_summary':
        content = generateBrandSummary(chefSummaries, 'Sole');
        break;
      case 'action_plan':
        content = generateActionPlan(chefSummaries);
        break;
      default:
        throw new Error('Invalid section');
    }

    const { error: updateError } = await supabase
      .from('weekly_executive_reports')
      .update({ [section]: content, updated_at: new Date().toISOString() })
      .eq('id', reportId);

    if (updateError) {
      throw updateError;
    }

    return new Response(
      JSON.stringify({ content }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error generating summary:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

function generateExecutiveSummary(summaries: any[], fiscalYear: number, period: number, week: number): string {
  const totalSales = summaries.reduce((sum, s) => sum + (s.total_sales || 0), 0);
  const avgFoodCost = summaries.reduce((sum, s) => sum + (s.food_cost_pct || 0), 0) / summaries.length;
  const avgLabourCost = summaries.reduce((sum, s) => sum + (s.labour_cost_pct || 0), 0) / summaries.length;

  return `Executive Summary - FY${fiscalYear} P${period}W${week}

Period-to-Date Performance:
- Total Sales: $${totalSales.toLocaleString()}
- Food Cost Average: ${avgFoodCost.toFixed(1)}%
- Labour Cost Average: ${avgLabourCost.toFixed(1)}%
- Locations Reporting: ${summaries.length}

Key Highlights:
${summaries.slice(0, 3).map(s => `- ${s.locations.name}: Strong performance with ${s.guest_count || 0} guests served`).join('\n')}

Areas Requiring Attention:
${summaries.filter(s => (s.food_cost_pct || 0) > 35).map(s => `- ${s.locations.name}: Food cost at ${s.food_cost_pct?.toFixed(1)}%`).join('\n') || '- All locations within targets'}`;
}

function generateBrandSummary(summaries: any[], brand: string): string {
  const brandSummaries = summaries.filter(s => s.locations.brand === brand);

  if (brandSummaries.length === 0) {
    return `No ${brand} locations reported this period.`;
  }

  const totalSales = brandSummaries.reduce((sum, s) => sum + (s.total_sales || 0), 0);
  const avgFoodCost = brandSummaries.reduce((sum, s) => sum + (s.food_cost_pct || 0), 0) / brandSummaries.length;

  return `${brand} Brand Summary

Performance Overview:
- Locations Reporting: ${brandSummaries.length}
- Combined Sales: $${totalSales.toLocaleString()}
- Average Food Cost: ${avgFoodCost.toFixed(1)}%

Location Highlights:
${brandSummaries.map(s => `
${s.locations.name}:
- Sales: $${(s.total_sales || 0).toLocaleString()}
- Food Cost: ${(s.food_cost_pct || 0).toFixed(1)}%
- Labour Cost: ${(s.labour_cost_pct || 0).toFixed(1)}%
- Guests: ${s.guest_count || 0}
`).join('\n')}`;
}

function generateActionPlan(summaries: any[]): string {
  const highFoodCost = summaries.filter(s => (s.food_cost_pct || 0) > 35);
  const highLabourCost = summaries.filter(s => (s.labour_cost_pct || 0) > 30);

  let plan = 'Action Plan\n\n';

  if (highFoodCost.length > 0) {
    plan += 'Food Cost Management:\n';
    highFoodCost.forEach(s => {
      plan += `- ${s.locations.name}: Review menu pricing and portion controls (Currently ${s.food_cost_pct?.toFixed(1)}%)\n`;
    });
    plan += '\n';
  }

  if (highLabourCost.length > 0) {
    plan += 'Labour Cost Optimization:\n';
    highLabourCost.forEach(s => {
      plan += `- ${s.locations.name}: Optimize scheduling and staffing levels (Currently ${s.labour_cost_pct?.toFixed(1)}%)\n`;
    });
    plan += '\n';
  }

  if (highFoodCost.length === 0 && highLabourCost.length === 0) {
    plan += 'Maintain Current Operations:\n';
    plan += '- All locations are performing within target metrics\n';
    plan += '- Continue monitoring weekly performance\n';
    plan += '- Focus on guest experience and service quality\n';
  }

  return plan;
}
