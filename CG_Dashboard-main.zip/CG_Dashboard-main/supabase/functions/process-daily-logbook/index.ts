import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface DailyLogbookData {
  locationName: string;
  reportDate: string;
  salesForecast: number | null;
  salesActual: number | null;
  varianceForecastToSales: number | null;
  scheduledLabor: number | null;
  actualLabor: number | null;
  laborCostVsSalesForecast: number | null;
  laborCostVsSalesActual: number | null;
  mtdForecast: number | null;
  mtdSales: number | null;
  varianceMtdForecastToSales: number | null;
  salesActualPreviousYear: number | null;
  actualLaborCostPreviousYear: number | null;
  weatherHigh: number | null;
  weatherLow: number | null;
  weatherConditions: string | null;
  journalEntry: string | null;
}

function parseMoneyValue(text: string): number | null {
  const match = text.match(/\$([0-9,]+(?:\.[0-9]{2})?)/);
  if (match) {
    const cleaned = match[1].replace(/,/g, '');
    return parseFloat(cleaned);
  }
  return null;
}

function parsePercentValue(text: string): number | null {
  const match = text.match(/(-?[0-9]+(?:\.[0-9]+)?)%/);
  if (match) {
    return parseFloat(match[1]);
  }
  return null;
}

function parseWeatherValue(text: string): { high: number | null; low: number | null; conditions: string | null } {
  const highMatch = text.match(/High:\s*([0-9.]+)/i);
  const lowMatch = text.match(/Low:\s*([0-9.]+)/i);

  let conditions = text.replace(/High:\s*[0-9.]+/i, '').replace(/Low:\s*[0-9.]+/i, '').trim();

  return {
    high: highMatch ? parseFloat(highMatch[1]) : null,
    low: lowMatch ? parseFloat(lowMatch[1]) : null,
    conditions: conditions || null
  };
}

function parseDailyLogbookEmail(bodyText: string): DailyLogbookData | null {
  const locationMatch = bodyText.match(/Company:\s*([^\r\n]+)/i);
  const dateMatch = bodyText.match(/Date:\s*(\d{4}-\d{2}-\d{2})/i);

  if (!locationMatch || !dateMatch) {
    return null;
  }

  const locationName = locationMatch[1].trim();
  const reportDate = dateMatch[1];

  const data: DailyLogbookData = {
    locationName,
    reportDate,
    salesForecast: null,
    salesActual: null,
    varianceForecastToSales: null,
    scheduledLabor: null,
    actualLabor: null,
    laborCostVsSalesForecast: null,
    laborCostVsSalesActual: null,
    mtdForecast: null,
    mtdSales: null,
    varianceMtdForecastToSales: null,
    salesActualPreviousYear: null,
    actualLaborCostPreviousYear: null,
    weatherHigh: null,
    weatherLow: null,
    weatherConditions: null,
    journalEntry: null,
  };

  const salesForecastMatch = bodyText.match(/Sales Forecast:\s*\$([0-9,]+(?:\.[0-9]{2})?)/i);
  if (salesForecastMatch) {
    data.salesForecast = parseMoneyValue(salesForecastMatch[0]);
  }

  const salesActualMatch = bodyText.match(/Sales Actual:\s*\$([0-9,]+(?:\.[0-9]{2})?)/i);
  if (salesActualMatch) {
    data.salesActual = parseMoneyValue(salesActualMatch[0]);
  }

  const varianceForecastMatch = bodyText.match(/Variance of Forecast to Sales:\s*(-?[0-9.]+)%/i);
  if (varianceForecastMatch) {
    data.varianceForecastToSales = parsePercentValue(varianceForecastMatch[0]);
  }

  const scheduledLaborMatch = bodyText.match(/Scheduled Labor:\s*\$([0-9,]+(?:\.[0-9]{2})?)/i);
  if (scheduledLaborMatch) {
    data.scheduledLabor = parseMoneyValue(scheduledLaborMatch[0]);
  }

  const actualLaborMatch = bodyText.match(/Actual Labor:\s*\$([0-9,]+(?:\.[0-9]{2})?)/i);
  if (actualLaborMatch) {
    data.actualLabor = parseMoneyValue(actualLaborMatch[0]);
  }

  const laborCostForecastMatch = bodyText.match(/Labor Cost vs\. Sales \(Forecast\):\s*([0-9.]+)%/i);
  if (laborCostForecastMatch) {
    data.laborCostVsSalesForecast = parsePercentValue(laborCostForecastMatch[0]);
  }

  const laborCostActualMatch = bodyText.match(/Labor Cost vs\. Sales \(Actual\):\s*([0-9.]+)%/i);
  if (laborCostActualMatch) {
    data.laborCostVsSalesActual = parsePercentValue(laborCostActualMatch[0]);
  }

  const mtdForecastMatch = bodyText.match(/MTD Forecast:\s*\$([0-9,]+(?:\.[0-9]{2})?)/i);
  if (mtdForecastMatch) {
    data.mtdForecast = parseMoneyValue(mtdForecastMatch[0]);
  }

  const mtdSalesMatch = bodyText.match(/MTD Sales:\s*\$([0-9,]+(?:\.[0-9]{2})?)/i);
  if (mtdSalesMatch) {
    data.mtdSales = parseMoneyValue(mtdSalesMatch[0]);
  }

  const varianceMtdMatch = bodyText.match(/Variance of MTD Forecast to Sales:\s*(-?[0-9.]+)%/i);
  if (varianceMtdMatch) {
    data.varianceMtdForecastToSales = parsePercentValue(varianceMtdMatch[0]);
  }

  const salesPrevYearMatch = bodyText.match(/Sales Actual \(Previous Year\):\s*\$([0-9,]+(?:\.[0-9]{2})?)/i);
  if (salesPrevYearMatch) {
    data.salesActualPreviousYear = parseMoneyValue(salesPrevYearMatch[0]);
  }

  const laborPrevYearMatch = bodyText.match(/Actual Labor Cost \(Previous Year\):\s*\$([0-9,]+(?:\.[0-9]{2})?)/i);
  if (laborPrevYearMatch) {
    data.actualLaborCostPreviousYear = parseMoneyValue(laborPrevYearMatch[0]);
  }

  const weatherMatch = bodyText.match(/Weather:\s*(.+?)(?:\n|\*)/i);
  if (weatherMatch) {
    const weather = parseWeatherValue(weatherMatch[1]);
    data.weatherHigh = weather.high;
    data.weatherLow = weather.low;
    data.weatherConditions = weather.conditions;
  }

  const journalMatch = bodyText.match(/(?:Journal|Notes)[:\s]+(.+?)(?=\n\n\n|This is an automated message|$)/is);
  if (journalMatch) {
    data.journalEntry = journalMatch[1].trim();
  }

  return data;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { emailId } = await req.json();

    if (!emailId) {
      return new Response(
        JSON.stringify({ success: false, error: "emailId is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: email, error: emailError } = await supabase
      .from("raw_emails")
      .select("*")
      .eq("id", emailId)
      .maybeSingle();

    if (emailError || !email) {
      return new Response(
        JSON.stringify({ success: false, error: "Email not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (!email.subject?.includes("Daily Logbook Summary")) {
      return new Response(
        JSON.stringify({ success: false, error: "Not a Daily Logbook Summary email" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const parsedData = parseDailyLogbookEmail(email.body_plain);

    if (!parsedData) {
      return new Response(
        JSON.stringify({ success: false, error: "Failed to parse email" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: mapping } = await supabase
      .from("location_mappings")
      .select("canonical_location_name")
      .eq("source_name", parsedData.locationName)
      .maybeSingle();

    const locationName = mapping?.canonical_location_name || parsedData.locationName;

    const { data: insertedData, error: insertError } = await supabase
      .from("daily_logbook")
      .upsert({
        location_name: locationName,
        report_date: parsedData.reportDate,
        sales_forecast: parsedData.salesForecast,
        sales_actual: parsedData.salesActual,
        variance_forecast_to_sales: parsedData.varianceForecastToSales,
        scheduled_labor: parsedData.scheduledLabor,
        actual_labor: parsedData.actualLabor,
        labor_cost_vs_sales_forecast: parsedData.laborCostVsSalesForecast,
        labor_cost_vs_sales_actual: parsedData.laborCostVsSalesActual,
        mtd_forecast: parsedData.mtdForecast,
        mtd_sales: parsedData.mtdSales,
        variance_mtd_forecast_to_sales: parsedData.varianceMtdForecastToSales,
        sales_actual_previous_year: parsedData.salesActualPreviousYear,
        actual_labor_cost_previous_year: parsedData.actualLaborCostPreviousYear,
        weather_high: parsedData.weatherHigh,
        weather_low: parsedData.weatherLow,
        weather_conditions: parsedData.weatherConditions,
        journal_entry: parsedData.journalEntry,
        raw_email_id: emailId,
        updated_at: new Date().toISOString(),
      }, {
        onConflict: 'location_name,report_date'
      })
      .select()
      .single();

    if (insertError) {
      console.error("Database error:", insertError);
      return new Response(
        JSON.stringify({ success: false, error: insertError.message }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({ success: true, data: insertedData }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error processing email:", error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
