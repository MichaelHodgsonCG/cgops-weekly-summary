import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface JournalEntry {
  location_name: string;
  report_date: string;
  sales_actual: number;
  journal_entry: string | null;
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method === "OPTIONS") {
      return new Response(null, {
        status: 200,
        headers: corsHeaders,
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const openaiKey = Deno.env.get("OPENAI_API_KEY");

    if (!openaiKey) {
      return new Response(
        JSON.stringify({ success: false, error: "OpenAI API key not configured" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    const { date, forceRegenerate = false, triggeredBy = 'manual' } = await req.json();

    if (!date) {
      return new Response(
        JSON.stringify({ success: false, error: "date is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Check if insights already exist
    if (!forceRegenerate) {
      const { data: existing } = await supabase
        .from('daily_insights')
        .select('id')
        .eq('analysis_date', date)
        .maybeSingle();

      if (existing) {
        return new Response(
          JSON.stringify({ success: true, exists: true, id: existing.id }),
          {
            status: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }
    }

    // Fetch all journal entries for the date
    const { data: entries, error: entriesError } = await supabase
      .from('daily_logbook')
      .select('location_name, report_date, sales_actual, journal_entry')
      .eq('report_date', date)
      .order('location_name');

    if (entriesError) {
      throw entriesError;
    }

    if (!entries || entries.length === 0) {
      return new Response(
        JSON.stringify({ success: false, error: "No journal entries found for this date" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Get all locations to determine missing ones
    const { data: allLocations } = await supabase
      .from('locations')
      .select('name')
      .order('name');

    const reportedLocations = entries.map(e => e.location_name);
    const missingLocations = (allLocations || [])
      .map(l => l.name)
      .filter(name => !reportedLocations.includes(name));

    // Build prompt for OpenAI
    const entriesText = entries
      .map(e => {
        const journal = e.journal_entry || 'No journal entry';
        return `Location: ${e.location_name}\nJournal Entry: ${journal}\n`;
      })
      .join('\n');

    const prompt = `You are analyzing daily restaurant operation reports. Read through the journal entries below and provide insights.

IMPORTANT INSTRUCTIONS:
- ONLY flag issues that are explicitly mentioned IN THE JOURNAL ENTRIES themselves
- DO NOT create concerns about missing data or locations that didn't report
- Missing locations are tracked separately - do not mention them in concerns
- Focus on actual operational issues: staffing problems, guest complaints, equipment failures, inventory issues, etc.
- Highlights should be positive notes: successful items, good guest interactions, strong sales, etc.
- Management Opportunities: ONLY flag entries where a problem/issue is described WITHOUT any indication of action, response, or follow-up.
- ALWAYS use the term "Guests" (never "Customers") when referring to restaurant patrons

CRITICAL for Management Opportunities:
- YOU MUST ONLY FLAG ISSUES THAT ARE ACTUALLY WRITTEN IN THE JOURNAL ENTRIES
- DO NOT INVENT, INFER, OR ASSUME issues that are not explicitly stated in the text
- ACTIONS COUNT: Making labor cuts, adjusting schedules, calling for repairs, ordering supplies, coaching staff, etc. are all valid management actions
- DO NOT FLAG if the manager mentions taking ANY action, even if brief (e.g., "cut labor early", "called technician", "spoke with team")
- ONLY FLAG if they describe a problem with NO mention of action whatsoever (e.g., "equipment is broken" with no mention of repair call)
- DO NOT FLAG proactive management decisions or operational adjustments - these show good judgment
- ONLY FLAG entries that read like pure venting or problem identification without any response
- If you cannot find the exact text to support a management opportunity, DO NOT include it

CRITICAL - LOCATION FIELD:
- The "location" field in your response MUST be the RESTAURANT NAME shown at the top of each journal entry (e.g., "Beertown Barrie")
- DO NOT use manager names (like "Scott Campbell" or "Chris Miller") as the location
- Each journal entry may contain notes from multiple managers, but they are ALL from the same restaurant location
- Use ONLY the restaurant name from "Location: [Restaurant Name]" at the start of each entry

Journal Entries:
${entriesText}

Analyze these entries and respond with a JSON object in this exact format:
{
  "summary": "A brief 1-2 sentence overview of the day's operations across all locations",
  "concerns": [
    {
      "location": "Restaurant Name (NOT manager name)",
      "issue": "Description of the concern from their journal entry",
      "severity": "low|medium|high"
    }
  ],
  "highlights": [
    {
      "location": "Restaurant Name (NOT manager name)",
      "note": "Positive observation from their journal entry"
    }
  ],
  "management_opportunities": [
    {
      "location": "Restaurant Name (NOT manager name)",
      "issue": "The problem described",
      "coaching_note": "Brief note about what action should have been mentioned (e.g., 'Should mention calling for repair', 'Should indicate follow-up plan', 'Should describe resolution steps')"
    }
  ],
  "themes": ["Theme 1", "Theme 2", "Theme 3"]
}

Rules:
- Only include concerns that are explicitly mentioned in the journal entries
- Do not invent or infer concerns that aren't written
- Do not mention missing locations in the concerns array
- Keep the summary focused on locations that reported
- Themes should reflect patterns across the actual journal entries
- Management opportunities should ONLY include problems stated with absolutely NO action or response mentioned. If any action is described (labor cuts, repairs called, adjustments made), DO NOT FLAG IT.
- ALWAYS use the restaurant name as the location, NEVER use manager names`;

    const startTime = Date.now();

    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "You are a restaurant operations analyst. Respond only with valid JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
        response_format: { type: "json_object" }
      })
    });

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text();
      console.error("OpenAI API error:", {
        status: openaiResponse.status,
        statusText: openaiResponse.statusText,
        body: errorText
      });
      throw new Error(`OpenAI API error (${openaiResponse.status}): ${errorText}`);
    }

    const openaiData = await openaiResponse.json();
    const aiResponse = JSON.parse(openaiData.choices[0].message.content);

    const processingDuration = Date.now() - startTime;

    // Prepare data for database
    const insightData = {
      analysis_date: date,
      ai_summary_json: { summary: aiResponse.summary || "" },
      concerns_json: aiResponse.concerns || [],
      highlights_json: aiResponse.highlights || [],
      management_opportunities_json: aiResponse.management_opportunities || [],
      themes_json: aiResponse.themes || [],
      missing_locations: missingLocations,
      concerns_count: (aiResponse.concerns || []).length,
      highlights_count: (aiResponse.highlights || []).length,
      management_opportunities_count: (aiResponse.management_opportunities || []).length,
      missing_locations_count: missingLocations.length,
      ai_provider: 'openai',
      processing_duration_ms: processingDuration,
      generated_at: new Date().toISOString(),
    };

    // Insert or update
    const { data: inserted, error: insertError } = await supabase
      .from('daily_insights')
      .upsert(insightData, {
        onConflict: 'analysis_date'
      })
      .select()
      .single();

    if (insertError) {
      throw insertError;
    }

    return new Response(
      JSON.stringify({ success: true, data: inserted }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error generating insights:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    const errorStack = error instanceof Error ? error.stack : undefined;

    console.error("Error details:", {
      message: errorMessage,
      stack: errorStack,
      date,
      triggeredBy
    });

    return new Response(
      JSON.stringify({
        success: false,
        error: errorMessage
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
