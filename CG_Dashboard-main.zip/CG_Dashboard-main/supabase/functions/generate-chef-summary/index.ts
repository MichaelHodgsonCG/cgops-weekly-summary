import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ChefSummaryData {
  id: string;
  location_name: string;
  food_cost_summary?: string;
  labour_summary?: string;
  boh_promo_summary?: string;
  notes?: string;
  action_plan_summary?: string;
  hiring_notes?: string;
  tm_mots_of_note?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { summaries } = await req.json() as { summaries: ChefSummaryData[] };

    if (!summaries || !Array.isArray(summaries)) {
      return new Response(
        JSON.stringify({ error: "Invalid request: summaries array required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const openaiApiKey = Deno.env.get("OPENAI_API_KEY");
    if (!openaiApiKey) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured" }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const results = await Promise.all(
      summaries.map(async (summary) => {
        const sections = [];

        if (summary.food_cost_summary) {
          sections.push(`Food Cost: ${summary.food_cost_summary}`);
        }
        if (summary.labour_summary) {
          sections.push(`Labour: ${summary.labour_summary}`);
        }
        if (summary.boh_promo_summary) {
          sections.push(`BOH Promo: ${summary.boh_promo_summary}`);
        }
        if (summary.notes) {
          sections.push(`Notes: ${summary.notes}`);
        }
        if (summary.action_plan_summary) {
          sections.push(`Action Plan: ${summary.action_plan_summary}`);
        }
        if (summary.hiring_notes) {
          sections.push(`Hiring: ${summary.hiring_notes}`);
        }
        if (summary.tm_mots_of_note) {
          sections.push(`Team Members: ${summary.tm_mots_of_note}`);
        }

        if (sections.length === 0) {
          return {
            id: summary.id,
            ai_summary: "No details available.",
          };
        }

        const prompt = `You are analyzing a restaurant chef's weekly summary. Provide a concise 2-3 sentence summary highlighting ONLY the most important and actionable details. Focus on critical issues, significant variances, and key action items.

${sections.join('\n\n')}

Provide a concise 2-3 sentence executive summary:`;

        const response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${openaiApiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [
              {
                role: "system",
                content: "You are a restaurant operations analyst. Provide concise, actionable summaries focusing on the most critical information."
              },
              {
                role: "user",
                content: prompt
              }
            ],
            temperature: 0.3,
            max_tokens: 200,
          }),
        });

        if (!response.ok) {
          throw new Error(`OpenAI API error: ${response.statusText}`);
        }

        const data = await response.json();
        const aiSummary = data.choices[0]?.message?.content?.trim() || "Unable to generate summary.";

        return {
          id: summary.id,
          ai_summary: aiSummary,
        };
      })
    );

    return new Response(
      JSON.stringify({ results }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error generating summaries:", error);
    return new Response(
      JSON.stringify({
        error: "Failed to generate summaries",
        details: error.message
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
