import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface GuestFeedback {
  locationName: string;
  reviewDate: string;
  reportDate: string;
  reviewerName: string | null;
  reviewSource: string;
  overallRating: number | null;
  foodRating: number | null;
  serviceRating: number | null;
  ambienceRating: number | null;
  valueRating: number | null;
  reviewText: string | null;
  visitDate: string | null;
}

function parseOpenTableReview(bodyText: string, validLocations: string[]): GuestFeedback[] {
  const reviews: GuestFeedback[] = [];

  // Extract the raw location text from the email
  const locationMatch = bodyText.match(/Daily review report[\s\S]*?([^\r\n<]+?)(?=<http:\/\/links\.opentable\.com|\r\n)/i);
  if (!locationMatch) {
    return reviews;
  }

  let rawLocationText = locationMatch[1].trim();

  // Clean up common email prefixes
  rawLocationText = rawLocationText.replace(/^:\s*New feedback for\s*/i, '').trim();
  rawLocationText = rawLocationText.replace(/^New feedback for\s*/i, '').trim();
  rawLocationText = rawLocationText.replace(/^:\s*/i, '').trim();

  // Match against valid location names
  let locationName = rawLocationText;
  for (const validLocation of validLocations) {
    // Try exact match first
    if (rawLocationText === validLocation) {
      locationName = validLocation;
      break;
    }

    // Try case-insensitive match
    if (rawLocationText.toLowerCase() === validLocation.toLowerCase()) {
      locationName = validLocation;
      break;
    }

    // Try partial match (contains)
    if (rawLocationText.toLowerCase().includes(validLocation.toLowerCase())) {
      locationName = validLocation;
      break;
    }

    // Try reverse partial match (location contains extracted text)
    if (validLocation.toLowerCase().includes(rawLocationText.toLowerCase())) {
      locationName = validLocation;
      break;
    }
  }

  const reportDateMatch = bodyText.match(/(?:Apr|Jan|Feb|Mar|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d+)[\s\S]*?Daily review report/i);
  const monthMatch = bodyText.match(/(Apr|Jan|Feb|Mar|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d+/i);

  let reportDate = '';
  if (reportDateMatch && monthMatch) {
    const day = reportDateMatch[1];
    const month = monthMatch[1];
    const currentYear = new Date().getFullYear();
    const monthMap: { [key: string]: string } = {
      'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04',
      'May': '05', 'Jun': '06', 'Jul': '07', 'Aug': '08',
      'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12'
    };
    reportDate = `${currentYear}-${monthMap[month]}-${day.padStart(2, '0')}`;
  }

  const overallRatingMatch = bodyText.match(/Overall rating[\s\S]*?([0-9.]+)/i);
  const overallRating = overallRatingMatch ? parseFloat(overallRatingMatch[1]) : null;

  const reviewSections = bodyText.split(/\[Review source logo:/);

  for (const section of reviewSections) {
    if (!section.includes('Reviewed') && !section.includes('Visited')) continue;

    const sourceMatch = section.match(/^([^\]]+)\]/);
    const reviewSource = sourceMatch ? sourceMatch[1].trim() : 'Unknown';

    const reviewerMatch = section.match(/\]\s*([^\r\n]+?)[\s\S]*?Reviewed/i);
    const reviewerName = reviewerMatch ? reviewerMatch[1].trim() : null;

    // Extract per-review rating from the first star rating marker, e.g. "[Star 1 of 5, 1 out of 5]"
    const perReviewRatingMatch = section.match(/\[Star 1 of 5,\s*([0-9.]+)\s*out of 5\]/i);
    const perReviewRating = perReviewRatingMatch ? parseFloat(perReviewRatingMatch[1]) : overallRating;

    const reviewDateMatch = section.match(/Reviewed\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d+),\s+(\d{4})/i);
    let reviewDate = reportDate;
    if (reviewDateMatch) {
      const monthMap: { [key: string]: string } = {
        'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04',
        'May': '05', 'Jun': '06', 'Jul': '07', 'Aug': '08',
        'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12'
      };
      const month = monthMap[reviewDateMatch[1]];
      const day = reviewDateMatch[2].padStart(2, '0');
      const year = reviewDateMatch[3];
      reviewDate = `${year}-${month}-${day}`;
    }

    const visitDateMatch = section.match(/Visited\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d+),\s+(\d{4}),?\s*(\d+:\d+\s*[ap]\.?m\.?)?/i);
    let visitDate = null;
    if (visitDateMatch) {
      const monthMap: { [key: string]: string } = {
        'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04',
        'May': '05', 'Jun': '06', 'Jul': '07', 'Aug': '08',
        'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12'
      };
      const month = monthMap[visitDateMatch[1]];
      const day = visitDateMatch[2].padStart(2, '0');
      const year = visitDateMatch[3];
      const time = visitDateMatch[4] || '12:00 p.m.';

      const hour24 = time.toLowerCase().includes('p.m.')
        ? (parseInt(time.split(':')[0]) % 12) + 12
        : parseInt(time.split(':')[0]) % 12;
      const minute = time.split(':')[1]?.match(/\d+/)?.[0] || '00';

      visitDate = `${year}-${month}-${day}T${hour24.toString().padStart(2, '0')}:${minute}:00`;
    }

    const reviewTextMatch = section.match(/Visited[^\r\n]+[\r\n]+([\s\S]+?)(?=\[Go to |Manage and reply|$)/i);
    let rawReviewText = reviewTextMatch ? reviewTextMatch[1].trim() : null;

    const foodMatch = rawReviewText?.match(/^Food\s+(\d+(?:\.\d+)?)\s*$/im);
    const serviceMatch = rawReviewText?.match(/^Service\s+(\d+(?:\.\d+)?)\s*$/im);
    const ambienceMatch = rawReviewText?.match(/^Ambience\s+(\d+(?:\.\d+)?)\s*$/im);
    const valueMatch = rawReviewText?.match(/^Value\s+(\d+(?:\.\d+)?)\s*$/im);

    const foodRating = foodMatch ? parseFloat(foodMatch[1]) : null;
    const serviceRating = serviceMatch ? parseFloat(serviceMatch[1]) : null;
    const ambienceRating = ambienceMatch ? parseFloat(ambienceMatch[1]) : null;
    const valueRating = valueMatch ? parseFloat(valueMatch[1]) : null;

    if (rawReviewText) {
      rawReviewText = rawReviewText
        .replace(/^Food\s+\d+(?:\.\d+)?\s*$/im, '')
        .replace(/^Service\s+\d+(?:\.\d+)?\s*$/im, '')
        .replace(/^Ambience\s+\d+(?:\.\d+)?\s*$/im, '')
        .replace(/^Value\s+\d+(?:\.\d+)?\s*$/im, '')
        .replace(/^Noise\s+\w+\s*$/im, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim() || null;
    }

    if (reviewerName || rawReviewText) {
      reviews.push({
        locationName,
        reviewDate,
        reportDate,
        reviewerName,
        reviewSource,
        overallRating: perReviewRating,
        foodRating,
        serviceRating,
        ambienceRating,
        valueRating,
        reviewText: rawReviewText,
        visitDate,
      });
    }
  }

  return reviews;
}

async function normalizeLocationName(supabase: any, sourceName: string): Promise<string> {
  // First, check if we have a mapping for this exact name
  const { data: mapping } = await supabase
    .from("location_mappings")
    .select("canonical_location_name")
    .eq("source_name", sourceName)
    .maybeSingle();

  if (mapping) {
    return mapping.canonical_location_name;
  }

  // If no mapping exists, try to find a close match in locations table
  const { data: locations } = await supabase
    .from("locations")
    .select("name");

  if (locations) {
    // Try exact match first
    const exactMatch = locations.find((loc: any) => loc.name === sourceName);
    if (exactMatch) {
      return exactMatch.name;
    }

    // Try case-insensitive match
    const caseInsensitiveMatch = locations.find(
      (loc: any) => loc.name.toLowerCase() === sourceName.toLowerCase()
    );
    if (caseInsensitiveMatch) {
      return caseInsensitiveMatch.name;
    }

    // Try partial match (contains)
    const partialMatch = locations.find(
      (loc: any) => loc.name.toLowerCase().includes(sourceName.toLowerCase()) ||
                    sourceName.toLowerCase().includes(loc.name.toLowerCase())
    );
    if (partialMatch) {
      return partialMatch.name;
    }
  }

  // If no match found, return the source name as-is
  return sourceName;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { emailId } = await req.json();

    if (!emailId) {
      return new Response(
        JSON.stringify({ success: false, error: "emailId is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: email, error: emailError } = await supabase
      .from("raw_emails")
      .select("*")
      .eq("id", emailId)
      .maybeSingle();

    if (emailError || !email) {
      return new Response(
        JSON.stringify({ success: false, error: "Email not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (!email.subject?.includes("Daily review report")) {
      return new Response(
        JSON.stringify({ success: false, error: "Not a Daily review report email" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Fetch all valid location names from the database
    const { data: locations, error: locationsError } = await supabase
      .from("locations")
      .select("name");

    if (locationsError) {
      return new Response(
        JSON.stringify({ success: false, error: "Failed to fetch locations" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const validLocationNames = locations?.map(loc => loc.name) || [];

    const reviews = parseOpenTableReview(email.body_plain, validLocationNames);

    if (reviews.length === 0) {
      return new Response(
        JSON.stringify({ success: false, error: "No reviews found in email" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const insertData = reviews.map(review => ({
      location_name: review.locationName,
      review_date: review.reviewDate,
      report_date: review.reportDate,
      reviewer_name: review.reviewerName,
      review_source: review.reviewSource,
      overall_rating: review.overallRating,
      food_rating: review.foodRating,
      service_rating: review.serviceRating,
      ambience_rating: review.ambienceRating,
      value_rating: review.valueRating,
      review_text: review.reviewText,
      visit_date: review.visitDate,
      raw_email_id: emailId,
      updated_at: new Date().toISOString(),
    }));

    const { data: insertedData, error: insertError } = await supabase
      .from("guest_feedback")
      .upsert(insertData, {
        onConflict: 'location_name,reviewer_name,review_date,review_source'
      })
      .select();

    if (insertError) {
      console.error("Database error:", insertError);
      return new Response(
        JSON.stringify({ success: false, error: insertError.message }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        count: insertedData?.length || 0,
        data: insertedData
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error processing email:", error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
