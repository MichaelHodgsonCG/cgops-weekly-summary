import { createClient } from "npm:@supabase/supabase-js@2.57.4";
import * as XLSX from "npm:xlsx@0.18.5";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SLPSalesData {
  locationName: string;
  totalDailySales: number | null;
  totalWtdSales: number | null;
  dailySalesVsProjections: number | null;
  wtdSalesVsProjections: number | null;
  dailySalesVsLastYear: number | null;
  wtdSalesVsLastYear: number | null;
  wtdSalesVsLastYearPct: number | null;
}

interface SLPLabourData {
  locationName: string;
  department: string;
  labourBudgetPct: number | null;
  dailyLabourActualPct: number | null;
  wtdLabourActualPct: number | null;
  dailyLabourProjectionPct: number | null;
  fullWeekLabourProjectionPct: number | null;
  dailyLabourDollarsVsProjections: number | null;
  wtdLabourDollarsVsProjections: number | null;
  wtdLabourPctVsBudgetPct: number | null;
  wtdLabourDollarsVsSales: number | null;
}

interface SLPPromoData {
  locationName: string;
  relationshipDollars: number | null;
  substandardDollars: number | null;
  totalPromoPct: number | null;
}

interface ParsedSLPData {
  sales: SLPSalesData[];
  labour: SLPLabourData[];
  promos: SLPPromoData[];
}

function parseNumericValue(value: string): number | null {
  if (!value || value.trim() === '') return null;
  const cleaned = value.replace(/,/g, '').replace(/\s+/g, '').trim();
  if (cleaned === '') return null;
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? null : parsed;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);

  return result;
}

async function normalizeLocationName(supabase: any, sourceName: string): Promise<string> {
  const { data: mapping } = await supabase
    .from("location_mappings")
    .select("canonical_location_name")
    .eq("source_name", sourceName)
    .maybeSingle();

  return mapping?.canonical_location_name || sourceName;
}

async function parseSLPCSV(csvContent: string, supabase: any): Promise<ParsedSLPData> {
  const lines = csvContent.split('\n').filter(line => line.trim());

  if (lines.length < 2) {
    throw new Error('Invalid CSV format: File is empty or missing header');
  }

  const headerLine = parseCSVLine(lines[1]);
  const TOTAL_KEY = '__TOTAL__';
  const rawLocations = headerLine.slice(2).filter(loc => loc && loc.trim() !== '');

  if (rawLocations.length === 0) {
    throw new Error('Invalid CSV format: No locations found in header');
  }

  const locations = await Promise.all(
    rawLocations.map(loc => normalizeLocationName(supabase, loc.trim()))
  );

  const salesMap = new Map<string, SLPSalesData>();
  const labourMap = new Map<string, SLPLabourData[]>();
  const promosMap = new Map<string, SLPPromoData>();

  const allLocations = [TOTAL_KEY, ...locations];

  allLocations.forEach(locationName => {
    salesMap.set(locationName, {
      locationName,
      totalDailySales: null,
      totalWtdSales: null,
      dailySalesVsProjections: null,
      wtdSalesVsProjections: null,
      dailySalesVsLastYear: null,
      wtdSalesVsLastYear: null,
      wtdSalesVsLastYearPct: null,
    });

    promosMap.set(locationName, {
      locationName,
      relationshipDollars: null,
      substandardDollars: null,
      totalPromoPct: null,
    });

    labourMap.set(locationName, []);
  });

  let currentDepartment = '';
  let currentDepartmentLabour = new Map<string, SLPLabourData>();

  for (let i = 2; i < lines.length; i++) {
    const line = lines[i];
    const columns = parseCSVLine(line);
    const kpiName = columns[0]?.trim() || '';

    if (!kpiName) continue;

    if (kpiName === 'BOH' || kpiName === 'FOH' || kpiName === 'Manager') {
      if (currentDepartment && currentDepartmentLabour.size > 0) {
        currentDepartmentLabour.forEach((labour, locName) => {
          const labourList = labourMap.get(locName);
          if (labourList) {
            labourList.push(labour);
          }
        });
      }

      currentDepartment = kpiName;
      currentDepartmentLabour = new Map();

      allLocations.forEach(locationName => {
        currentDepartmentLabour.set(locationName, {
          locationName,
          department: currentDepartment,
          labourBudgetPct: null,
          dailyLabourActualPct: null,
          wtdLabourActualPct: null,
          dailyLabourProjectionPct: null,
          fullWeekLabourProjectionPct: null,
          dailyLabourDollarsVsProjections: null,
          wtdLabourDollarsVsProjections: null,
          wtdLabourPctVsBudgetPct: null,
          wtdLabourDollarsVsSales: null,
        });
      });
      continue;
    }

    if (kpiName === 'Maintenance' || kpiName === 'PUSH TEST' || kpiName === 'TEST' || kpiName === 'Promos') {
      if (currentDepartment && currentDepartmentLabour.size > 0) {
        currentDepartmentLabour.forEach((labour, locName) => {
          const labourList = labourMap.get(locName);
          if (labourList) {
            labourList.push(labour);
          }
        });
        currentDepartment = '';
        currentDepartmentLabour = new Map();
      }
      continue;
    }

    const getColValue = (locationName: string, idx: number) =>
      locationName === TOTAL_KEY ? parseNumericValue(columns[1]) : parseNumericValue(columns[idx + 1]);

    if (kpiName.startsWith('1. Total Daily Sales')) {
      allLocations.forEach((locationName, idx) => {
        const sales = salesMap.get(locationName);
        if (sales) sales.totalDailySales = getColValue(locationName, idx);
      });
    } else if (kpiName.startsWith('2. Total WTD Sales')) {
      allLocations.forEach((locationName, idx) => {
        const sales = salesMap.get(locationName);
        if (sales) sales.totalWtdSales = getColValue(locationName, idx);
      });
    } else if (kpiName.startsWith('3. Daily Sales +/- Projections')) {
      allLocations.forEach((locationName, idx) => {
        const sales = salesMap.get(locationName);
        if (sales) sales.dailySalesVsProjections = getColValue(locationName, idx);
      });
    } else if (kpiName.startsWith('4. WTD Sales +/- Projections')) {
      allLocations.forEach((locationName, idx) => {
        const sales = salesMap.get(locationName);
        if (sales) sales.wtdSalesVsProjections = getColValue(locationName, idx);
      });
    } else if (kpiName.startsWith('5. Daily Sales +/- Last Year')) {
      allLocations.forEach((locationName, idx) => {
        const sales = salesMap.get(locationName);
        if (sales) sales.dailySalesVsLastYear = getColValue(locationName, idx);
      });
    } else if (kpiName.startsWith('6. WTD Sales +/- Last Year')) {
      allLocations.forEach((locationName, idx) => {
        const sales = salesMap.get(locationName);
        if (sales) sales.wtdSalesVsLastYear = getColValue(locationName, idx);
      });
    } else if (kpiName.startsWith('7. WTD Sales +/- Last Year %')) {
      allLocations.forEach((locationName, idx) => {
        const sales = salesMap.get(locationName);
        if (sales) sales.wtdSalesVsLastYearPct = getColValue(locationName, idx);
      });
    }

    if (currentDepartment && kpiName.includes(': 1. Labour Budget %')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.labourBudgetPct = getColValue(locationName, idx);
      });
    } else if (currentDepartment && kpiName.includes(': 2. Daily Labour Actual % of Sales')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.dailyLabourActualPct = getColValue(locationName, idx);
      });
    } else if (currentDepartment && kpiName.includes(': 3. WTD Labour Actual % of Sales')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.wtdLabourActualPct = getColValue(locationName, idx);
      });
    } else if (currentDepartment && kpiName.includes(': 4. Daily Labour Projection % of Sales')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.dailyLabourProjectionPct = getColValue(locationName, idx);
      });
    } else if (currentDepartment && kpiName.includes(': 5. Full Week Labour Projection % of Sales')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.fullWeekLabourProjectionPct = getColValue(locationName, idx);
      });
    } else if (currentDepartment && kpiName.includes(': 6. Daily Labour $ +/- Labour Projections')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.dailyLabourDollarsVsProjections = getColValue(locationName, idx);
      });
    } else if (currentDepartment && kpiName.includes(': 7. WTD Labour $ +/- Labour Projections')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.wtdLabourDollarsVsProjections = getColValue(locationName, idx);
      });
    } else if (currentDepartment && kpiName.includes(': 8. WTD Labour % +/- Labour Budget %')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.wtdLabourPctVsBudgetPct = getColValue(locationName, idx);
      });
    } else if (currentDepartment && kpiName.includes(': 9 WTD Labour $ +/- Relative to Sales')) {
      allLocations.forEach((locationName, idx) => {
        const labour = currentDepartmentLabour.get(locationName);
        if (labour) labour.wtdLabourDollarsVsSales = getColValue(locationName, idx);
      });
    }

    if (kpiName.startsWith('Relationship $')) {
      allLocations.forEach((locationName, idx) => {
        const promo = promosMap.get(locationName);
        if (promo) promo.relationshipDollars = getColValue(locationName, idx);
      });
    } else if (kpiName.startsWith('Substandard $')) {
      allLocations.forEach((locationName, idx) => {
        const promo = promosMap.get(locationName);
        if (promo) promo.substandardDollars = getColValue(locationName, idx);
      });
    } else if (kpiName.startsWith('Total Promo %')) {
      allLocations.forEach((locationName, idx) => {
        const promo = promosMap.get(locationName);
        if (promo) promo.totalPromoPct = getColValue(locationName, idx);
      });
    }
  }

  if (currentDepartment && currentDepartmentLabour.size > 0) {
    currentDepartmentLabour.forEach((labour, locName) => {
      const labourList = labourMap.get(locName);
      if (labourList) {
        labourList.push(labour);
      }
    });
  }

  const sales = Array.from(salesMap.values());
  const labour = Array.from(labourMap.values()).flat();
  const promos = Array.from(promosMap.values());

  return { sales, labour, promos };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { fileContent, fileType } = await req.json();

    if (!fileContent) {
      return new Response(
        JSON.stringify({ success: false, error: "fileContent is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    let csvContent: string;

    if (fileType === 'excel') {
      const binaryString = atob(fileContent);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const workbook = XLSX.read(bytes, { type: 'array' });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      csvContent = XLSX.utils.sheet_to_csv(firstSheet);
    } else {
      csvContent = fileContent;
    }

    const parsedData = await parseSLPCSV(csvContent, supabase);

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const reportDate = yesterday.toISOString().split('T')[0];
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const reportName = dayNames[yesterday.getDay()];

    const { data: reportData, error: reportError } = await supabase
      .from('slp_reports')
      .insert({
        report_date: reportDate,
        file_name: reportName,
      })
      .select()
      .single();

    if (reportError) throw reportError;

    const reportId = reportData.id;

    const salesInserts = parsedData.sales.map(sale => ({
      report_id: reportId,
      location_name: sale.locationName,
      total_daily_sales: sale.totalDailySales,
      total_wtd_sales: sale.totalWtdSales,
      daily_sales_vs_projections: sale.dailySalesVsProjections,
      wtd_sales_vs_projections: sale.wtdSalesVsProjections,
      daily_sales_vs_last_year: sale.dailySalesVsLastYear,
      wtd_sales_vs_last_year: sale.wtdSalesVsLastYear,
      wtd_sales_vs_last_year_pct: sale.wtdSalesVsLastYearPct,
    }));

    const labourInserts = parsedData.labour.map(labour => ({
      report_id: reportId,
      location_name: labour.locationName,
      department: labour.department,
      labour_budget_pct: labour.labourBudgetPct,
      daily_labour_actual_pct: labour.dailyLabourActualPct,
      wtd_labour_actual_pct: labour.wtdLabourActualPct,
      daily_labour_projection_pct: labour.dailyLabourProjectionPct,
      full_week_labour_projection_pct: labour.fullWeekLabourProjectionPct,
      daily_labour_dollars_vs_projections: labour.dailyLabourDollarsVsProjections,
      wtd_labour_dollars_vs_projections: labour.wtdLabourDollarsVsProjections,
      wtd_labour_pct_vs_budget_pct: labour.wtdLabourPctVsBudgetPct,
      wtd_labour_dollars_vs_sales: labour.wtdLabourDollarsVsSales,
    }));

    const promoInserts = parsedData.promos.map(promo => ({
      report_id: reportId,
      location_name: promo.locationName,
      relationship_dollars: promo.relationshipDollars,
      substandard_dollars: promo.substandardDollars,
      total_promo_pct: promo.totalPromoPct,
    }));

    const { error: salesError } = await supabase.from('slp_sales_data').insert(salesInserts);
    if (salesError) throw salesError;

    const { error: labourError } = await supabase.from('slp_labor_data').insert(labourInserts);
    if (labourError) throw labourError;

    const { error: promosError } = await supabase.from('slp_promo_data').insert(promoInserts);
    if (promosError) throw promosError;

    return new Response(
      JSON.stringify({
        success: true,
        message: "SLP data processed successfully",
        stats: {
          sales: salesInserts.length,
          labour: labourInserts.length,
          promos: promoInserts.length
        }
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error processing SLP attachment:", error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
