/*
  # Add AI Summary Column to Weekly Chef Summary

  1. Changes
    - Add `ai_summary` column to `weekly_chef_summary` table
    - This will store 2-3 sentence AI-generated summaries of the most important details
  
  2. Notes
    - Using text data type to accommodate variable length summaries
    - Column is nullable to allow gradual population
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'weekly_chef_summary' AND column_name = 'ai_summary'
  ) THEN
    ALTER TABLE weekly_chef_summary ADD COLUMN ai_summary text;
  END IF;
END $$;
