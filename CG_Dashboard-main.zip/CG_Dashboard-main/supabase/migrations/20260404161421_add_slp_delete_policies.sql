/*
  # Add DELETE policies for SLP tables

  ## Overview
  Adds missing DELETE policies to allow authenticated users to delete SLP reports and related data.

  ## Changes
  - Add DELETE policy for `slp_reports` table
  - Add DELETE policy for `slp_sales_data` table  
  - Add DELETE policy for `slp_labor_data` table
  - Add DELETE policy for `slp_promo_data` table

  ## Security
  All policies allow authenticated users to delete records.
  The ON DELETE CASCADE foreign key constraints will automatically handle child record deletion.
*/

-- Add DELETE policy for slp_reports
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'slp_reports' 
    AND policyname = 'Authenticated users can delete SLP reports'
  ) THEN
    CREATE POLICY "Authenticated users can delete SLP reports"
      ON slp_reports FOR DELETE
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Add DELETE policy for slp_sales_data
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'slp_sales_data' 
    AND policyname = 'Authenticated users can delete SLP sales data'
  ) THEN
    CREATE POLICY "Authenticated users can delete SLP sales data"
      ON slp_sales_data FOR DELETE
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Add DELETE policy for slp_labor_data
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'slp_labor_data' 
    AND policyname = 'Authenticated users can delete SLP labor data'
  ) THEN
    CREATE POLICY "Authenticated users can delete SLP labor data"
      ON slp_labor_data FOR DELETE
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Add DELETE policy for slp_promo_data
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'slp_promo_data' 
    AND policyname = 'Authenticated users can delete SLP promo data'
  ) THEN
    CREATE POLICY "Authenticated users can delete SLP promo data"
      ON slp_promo_data FOR DELETE
      TO authenticated
      USING (true);
  END IF;
END $$;