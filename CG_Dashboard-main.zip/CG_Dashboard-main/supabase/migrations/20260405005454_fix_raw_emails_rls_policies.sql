/*
  # Fix raw_emails RLS policies
  
  1. Changes
    - Drop conflicting RLS policies on raw_emails table
    - Create single comprehensive policy for authenticated users to view all emails
    - Ensure service role can insert emails (bypasses RLS by default)
  
  2. Security
    - All authenticated users can view raw emails (for admin UI access)
    - Service role (edge function) can insert without restrictions
*/

-- Drop existing conflicting policies
DROP POLICY IF EXISTS "Authenticated users can view all emails" ON raw_emails;
DROP POLICY IF EXISTS "Admins can view raw emails" ON raw_emails;
DROP POLICY IF EXISTS "Webhooks can insert emails" ON raw_emails;

-- Create single policy for authenticated users to view all emails
CREATE POLICY "Authenticated users can view all raw emails"
  ON raw_emails
  FOR SELECT
  TO authenticated
  USING (true);

-- Note: Service role bypasses RLS, so no INSERT policy needed for webhooks
-- The edge function uses SUPABASE_SERVICE_ROLE_KEY which has full access
