/*
  # Backfill dismissed_review_ids from latest_review_date

  ## Summary
  The previous migration added the dismissed_review_ids column but all existing rows
  have an empty array because they were created by the old date-based dismissal system.
  This migration backfills dismissed_review_ids for every existing dismissed_alerts row
  by collecting the IDs of all low-scoring guest_feedback rows whose review_date is on
  or before the stored latest_review_date for that location.

  A "low-scoring" review is any review with at least one category rating below 4 stars.

  ## Changes
  - `dismissed_alerts` rows with empty dismissed_review_ids and a non-null latest_review_date
    are updated to include the IDs of all matching low-scoring reviews for that location
    up to the stored latest_review_date.

  ## Notes
  - Only rows where dismissed_review_ids is currently empty AND latest_review_date is set
    are updated — this prevents accidental overwrites of any rows already using the new system.
  - After this migration runs, all existing dismissals will behave correctly with the
    per-review-ID logic in the frontend.
*/

UPDATE dismissed_alerts da
SET dismissed_review_ids = (
  SELECT COALESCE(array_agg(gf.id::text), '{}')
  FROM guest_feedback gf
  WHERE gf.location_name = da.location_name
    AND gf.review_date <= da.latest_review_date::date
    AND (
      gf.overall_rating < 4
      OR gf.food_rating < 4
      OR gf.service_rating < 4
      OR gf.ambience_rating < 4
      OR gf.value_rating < 4
    )
)
WHERE da.dismissed_review_ids = '{}'
  AND da.latest_review_date IS NOT NULL;
