/*
  # Setup automatic daily insights generation

  1. Extensions
    - Enable pg_cron extension for scheduled jobs
    - Enable pg_net extension for HTTP requests
    
  2. Scheduled Job
    - Create a cron job to run at 5:00 AM EST (9:00 AM UTC) daily
    - Calls the generate-daily-insights edge function
    - Generates insights for the previous day automatically
*/

CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

SELECT cron.unschedule('generate-daily-insights-job')
WHERE EXISTS (
  SELECT 1 FROM cron.job WHERE jobname = 'generate-daily-insights-job'
);

SELECT cron.schedule(
  'generate-daily-insights-job',
  '0 9 * * *',
  $$SELECT net.http_post(
    url := 'https://' || current_setting('request.headers')::json->>'host' || '/functions/v1/generate-daily-insights',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := jsonb_build_object('date', (CURRENT_DATE - INTERVAL '1 day')::text)
  )$$
);
