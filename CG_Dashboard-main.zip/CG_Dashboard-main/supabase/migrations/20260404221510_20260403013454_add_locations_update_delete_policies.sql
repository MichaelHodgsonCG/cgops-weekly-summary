/*
  # Add Update and Delete Policies for Locations Table

  1. Changes
    - Add UPDATE policy for locations table to allow editing location names and codes
    - Add DELETE policy for locations table to allow removing locations
  
  2. Security
    - Both policies allow public access (no authentication required)
    - Consistent with existing SELECT and INSERT policies
*/

-- Add update policy for locations
CREATE POLICY "Anyone can update locations"
  ON locations FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Add delete policy for locations
CREATE POLICY "Anyone can delete locations"
  ON locations FOR DELETE
  TO public
  USING (true);