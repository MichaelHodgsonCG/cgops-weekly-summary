/*
  # Allow anonymous select for weekly chef summaries
  
  1. Changes
    - Add policy to allow anon role to select chef summaries
    - This ensures anon can both insert and read the data
  
  2. Security
    - RLS remains enabled
    - Select policy added for anon role
*/

CREATE POLICY "Allow anon to select chef summaries"
  ON weekly_chef_summary
  FOR SELECT
  TO anon
  USING (true);
