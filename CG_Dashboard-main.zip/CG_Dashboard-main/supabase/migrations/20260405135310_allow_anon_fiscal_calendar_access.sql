/*
  # Allow Anonymous Access to Fiscal Calendar

  1. Changes
    - Update RLS policies to allow anonymous (anon) users full access
    - This is needed because the app uses custom authentication (localStorage)
    - The app doesn't use Supabase Auth, so all requests use the anon key
  
  2. Security Note
    - Since this app uses custom auth in the frontend, the fiscal calendar
      is managed by app-level permissions (admin checks in React)
    - Database-level security relies on the anon key not being exposed maliciously
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Authenticated users can read fiscal calendar" ON fiscal_calendar;
DROP POLICY IF EXISTS "Anonymous users can read fiscal calendar" ON fiscal_calendar;
DROP POLICY IF EXISTS "Authenticated users can insert fiscal calendar" ON fiscal_calendar;
DROP POLICY IF EXISTS "Authenticated users can update fiscal calendar" ON fiscal_calendar;
DROP POLICY IF EXISTS "Authenticated users can delete fiscal calendar" ON fiscal_calendar;

-- Allow anyone to read fiscal calendar
CREATE POLICY "Anyone can read fiscal calendar"
  ON fiscal_calendar
  FOR SELECT
  USING (true);

-- Allow anyone to insert fiscal calendar entries
CREATE POLICY "Anyone can insert fiscal calendar"
  ON fiscal_calendar
  FOR INSERT
  WITH CHECK (true);

-- Allow anyone to update fiscal calendar entries
CREATE POLICY "Anyone can update fiscal calendar"
  ON fiscal_calendar
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- Allow anyone to delete fiscal calendar entries
CREATE POLICY "Anyone can delete fiscal calendar"
  ON fiscal_calendar
  FOR DELETE
  USING (true);
