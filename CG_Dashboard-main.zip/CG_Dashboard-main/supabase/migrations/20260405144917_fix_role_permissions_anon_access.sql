/*
  # Fix role_permissions RLS for anonymous access

  1. Changes
    - Drop existing authenticated-only policies
    - Add new policies that allow anonymous users to insert and delete role_permissions
    - Maintains read access for all users
  
  2. Security
    - Allows anonymous users to manage role permissions
    - This is appropriate for internal admin tools without authentication
*/

-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Authenticated users can assign permissions" ON role_permissions;
DROP POLICY IF EXISTS "Authenticated users can remove permissions" ON role_permissions;

-- Add new policies for anonymous access
CREATE POLICY "Anyone can assign permissions"
  ON role_permissions
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can remove permissions"
  ON role_permissions
  FOR DELETE
  TO public
  USING (true);
