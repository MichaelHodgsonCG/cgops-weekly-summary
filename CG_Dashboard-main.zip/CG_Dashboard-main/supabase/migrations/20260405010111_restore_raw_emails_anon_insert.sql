/*
  # Restore anon INSERT policy for raw_emails
  
  1. Changes
    - Restore policy allowing anon role to insert emails
    - This allows the webhook endpoint to receive emails without authentication
    - Maintains existing SELECT policy for authenticated users
  
  2. Security
    - Anon (public) can insert emails (webhook endpoint)
    - Authenticated users can view all emails
*/

-- Restore policy for anon role to insert emails (for webhook)
CREATE POLICY "Webhooks can insert emails"
  ON raw_emails
  FOR INSERT
  TO anon
  WITH CHECK (true);
