/*
  # Create Weekly Executive Reports Table

  1. New Tables
    - `weekly_executive_reports`
      - `id` (uuid, primary key)
      - `fiscal_year` (integer) - The fiscal year for this report
      - `period_number` (integer) - The period number (1-13)
      - `week_number` (integer) - The week number within the period
      - `executive_summary` (text) - High-level summary for executives
      - `beertown_summary` (text) - Beertown brand summary
      - `trinity_summary` (text) - Trinity brand summary
      - `sole_summary` (text) - Sole brand summary
      - `action_plan` (text) - Key action items
      - `consolidated_metrics` (jsonb) - Consolidated financial metrics
      - `status` (text) - Report status: 'draft' or 'final'
      - `finalized_at` (timestamptz) - When the report was finalized
      - `created_at` (timestamptz) - When the report was created
      - `updated_at` (timestamptz) - When the report was last updated

  2. Security
    - Enable RLS on `weekly_executive_reports` table
    - Add policies for authenticated users to manage reports
    - Add policy for anonymous users to read/write reports (temporary for development)
*/

CREATE TABLE IF NOT EXISTS weekly_executive_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fiscal_year integer NOT NULL,
  period_number integer NOT NULL,
  week_number integer NOT NULL,
  executive_summary text DEFAULT '',
  beertown_summary text DEFAULT '',
  trinity_summary text DEFAULT '',
  sole_summary text DEFAULT '',
  action_plan text DEFAULT '',
  consolidated_metrics jsonb DEFAULT '{}',
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'final')),
  finalized_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(fiscal_year, period_number, week_number)
);

ALTER TABLE weekly_executive_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anon select weekly_executive_reports"
  ON weekly_executive_reports
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow anon insert weekly_executive_reports"
  ON weekly_executive_reports
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow anon update weekly_executive_reports"
  ON weekly_executive_reports
  FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow anon delete weekly_executive_reports"
  ON weekly_executive_reports
  FOR DELETE
  TO anon
  USING (true);

CREATE POLICY "Authenticated users can select weekly_executive_reports"
  ON weekly_executive_reports
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert weekly_executive_reports"
  ON weekly_executive_reports
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update weekly_executive_reports"
  ON weekly_executive_reports
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete weekly_executive_reports"
  ON weekly_executive_reports
  FOR DELETE
  TO authenticated
  USING (true);