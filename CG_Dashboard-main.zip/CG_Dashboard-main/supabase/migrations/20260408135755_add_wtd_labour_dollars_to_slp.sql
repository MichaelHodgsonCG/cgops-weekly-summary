/*
  # Add WTD Labour Dollars to SLP Labour Data

  1. Changes
    - Add `wtd_labour_dollars` column to `slp_labor_data` table to store total labour dollars
  
  2. Notes
    - This field captures the total WTD labour cost in dollars for each location/department
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'slp_labor_data' AND column_name = 'wtd_labour_dollars'
  ) THEN
    ALTER TABLE slp_labor_data ADD COLUMN wtd_labour_dollars numeric;
  END IF;
END $$;