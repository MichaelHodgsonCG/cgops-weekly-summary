/*
  # Add exclude_from_reporting flag to locations

  1. Changes
    - Add `exclude_from_reporting` boolean column to `locations` table
    - Defaults to false (include in reporting)
    - Allows marking locations like HQ that shouldn't appear in reports

  2. Notes
    - Existing locations will default to being included in reports
    - No RLS changes needed as this uses existing location policies
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations' AND column_name = 'exclude_from_reporting'
  ) THEN
    ALTER TABLE locations ADD COLUMN exclude_from_reporting boolean DEFAULT false NOT NULL;
  END IF;
END $$;