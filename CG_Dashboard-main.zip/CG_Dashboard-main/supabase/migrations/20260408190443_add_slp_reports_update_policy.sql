/*
  # Add UPDATE policy for slp_reports

  The slp_reports table was missing an UPDATE policy, which prevented
  renaming reports. This adds a permissive update policy consistent
  with the existing insert/select/delete policies.
*/

CREATE POLICY "Anyone can update SLP reports"
  ON slp_reports
  FOR UPDATE
  USING (true)
  WITH CHECK (true);
