/*
  # Create daily_logbook table for Daily Logbook Summary emails

  1. New Tables
    - `daily_logbook`
      - `id` (uuid, primary key)
      - `location_id` (uuid, foreign key to locations table, nullable for now)
      - `location_name` (text) - Raw location name from email
      - `report_date` (date) - Date of the report (e.g., 2026-04-03)
      - `sales_forecast` (numeric) - Sales Forecast amount
      - `sales_actual` (numeric) - Sales Actual amount
      - `variance_forecast_to_sales` (numeric) - Variance of Forecast to Sales %
      - `scheduled_labor` (numeric) - Scheduled Labor cost
      - `actual_labor` (numeric) - Actual Labor cost
      - `labor_cost_vs_sales_forecast` (numeric) - Labor Cost vs. Sales (Forecast) %
      - `labor_cost_vs_sales_actual` (numeric) - Labor Cost vs. Sales (Actual) %
      - `mtd_forecast` (numeric) - MTD Forecast amount
      - `mtd_sales` (numeric) - MTD Sales amount
      - `variance_mtd_forecast_to_sales` (numeric) - Variance of MTD Forecast to Sales %
      - `sales_actual_previous_year` (numeric) - Sales Actual (Previous Year)
      - `actual_labor_cost_previous_year` (numeric) - Actual Labor Cost (Previous Year)
      - `weather_high` (numeric) - High temperature
      - `weather_low` (numeric) - Low temperature
      - `weather_conditions` (text) - Weather conditions description
      - `raw_email_id` (uuid, foreign key to raw_emails table, nullable)
      - `created_at` (timestamptz) - Database insertion timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Indexes
    - Index on `location_name` for location filtering
    - Index on `report_date` for date range queries
    - Unique index on `location_name` + `report_date` to prevent duplicates

  3. Security
    - Enable RLS on `daily_logbook` table
    - Add policy for authenticated users to view all records
    - Add policy for authenticated users to insert records
    - Add policy for authenticated users to update records

  ## Notes
  - Stores parsed data from Daily Logbook Summary emails
  - All numeric fields are nullable to handle missing data
  - Location_id is nullable for now, can be linked later
  - Unique constraint prevents duplicate entries for same location/date
*/

CREATE TABLE IF NOT EXISTS daily_logbook (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid REFERENCES locations(id) ON DELETE SET NULL,
  location_name text NOT NULL DEFAULT '',
  report_date date NOT NULL,
  sales_forecast numeric(12, 2),
  sales_actual numeric(12, 2),
  variance_forecast_to_sales numeric(6, 2),
  scheduled_labor numeric(12, 2),
  actual_labor numeric(12, 2),
  labor_cost_vs_sales_forecast numeric(6, 2),
  labor_cost_vs_sales_actual numeric(6, 2),
  mtd_forecast numeric(12, 2),
  mtd_sales numeric(12, 2),
  variance_mtd_forecast_to_sales numeric(6, 2),
  sales_actual_previous_year numeric(12, 2),
  actual_labor_cost_previous_year numeric(12, 2),
  weather_high numeric(5, 2),
  weather_low numeric(5, 2),
  weather_conditions text,
  raw_email_id uuid REFERENCES raw_emails(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_daily_logbook_location_name ON daily_logbook(location_name);
CREATE INDEX IF NOT EXISTS idx_daily_logbook_report_date ON daily_logbook(report_date DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_daily_logbook_unique_location_date ON daily_logbook(location_name, report_date);

ALTER TABLE daily_logbook ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view daily logbook"
  ON daily_logbook
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert daily logbook"
  ON daily_logbook
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update daily logbook"
  ON daily_logbook
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);