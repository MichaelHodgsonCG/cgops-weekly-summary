/*
  # Allow anonymous insert for weekly chef summaries
  
  1. Changes
    - Add policy to allow anon role to insert chef summaries
    - This is needed because the app uses PIN-based auth, not Supabase Auth
    - The authenticated user check happens in the application layer
  
  2. Security
    - RLS remains enabled
    - Insert policy added for anon role
*/

CREATE POLICY "Allow anon to insert chef summaries"
  ON weekly_chef_summary
  FOR INSERT
  TO anon
  WITH CHECK (true);
