/*
  # Create P&L Weekly Values View
  
  1. Purpose
    - Automatically calculate weekly P&L values from Period-To-Date (PTD) data
    - Weekly Value = Current Week PTD - Previous Week PTD
    - For Week 1 of each period, Weekly Value = PTD (no previous week)
  
  2. Calculation Logic
    - Weeks 2-4: Current PTD minus Previous Week PTD
    - Week 1: PTD value (no subtraction needed)
  
  3. Key Metrics Included
    - Total Sales
    - Cost of Sales (Food)
    - Kitchen Labour
    - EBITDA
    - All other line items
  
  4. Benefits
    - No data duplication
    - Always accurate (recalculates from source data)
    - Automatically updates when PTD data changes
*/

-- Create view for weekly P&L values calculated from PTD data
CREATE OR REPLACE VIEW pl_weekly_values AS
WITH ranked_pl AS (
  -- Add row numbers to identify previous week for each location/line item
  SELECT 
    pli.id,
    pli.location_id,
    pli.week_ending_date,
    pli.line_item_name,
    pli.current_actual,
    pli.current_budget,
    fc.fiscal_year,
    fc.period,
    fc.week,
    -- Get previous week's PTD value for the same location and line item
    LAG(pli.current_actual) OVER (
      PARTITION BY pli.location_id, pli.line_item_name, fc.fiscal_year, fc.period 
      ORDER BY fc.week
    ) as previous_week_actual,
    LAG(pli.current_budget) OVER (
      PARTITION BY pli.location_id, pli.line_item_name, fc.fiscal_year, fc.period 
      ORDER BY fc.week
    ) as previous_week_budget
  FROM pl_line_items pli
  JOIN fiscal_calendar fc ON pli.week_ending_date = fc.end_date
)
SELECT 
  id,
  location_id,
  week_ending_date,
  line_item_name,
  fiscal_year,
  period,
  week,
  -- PTD values (original)
  current_actual as ptd_actual,
  current_budget as ptd_budget,
  -- Weekly values (calculated)
  CASE 
    WHEN week = 1 THEN current_actual::numeric
    ELSE (current_actual::numeric - COALESCE(previous_week_actual::numeric, 0))
  END as weekly_actual,
  CASE 
    WHEN week = 1 THEN current_budget::numeric
    ELSE (current_budget::numeric - COALESCE(previous_week_budget::numeric, 0))
  END as weekly_budget,
  -- Calculate variance
  CASE 
    WHEN week = 1 THEN (current_actual::numeric - current_budget::numeric)
    ELSE (
      (current_actual::numeric - COALESCE(previous_week_actual::numeric, 0)) -
      (current_budget::numeric - COALESCE(previous_week_budget::numeric, 0))
    )
  END as weekly_variance
FROM ranked_pl;

-- Grant access to the view
GRANT SELECT ON pl_weekly_values TO authenticated;
GRANT SELECT ON pl_weekly_values TO anon;
