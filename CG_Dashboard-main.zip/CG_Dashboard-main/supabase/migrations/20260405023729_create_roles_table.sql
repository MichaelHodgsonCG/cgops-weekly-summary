/*
  # Create Roles Table

  1. New Tables
    - `roles`
      - `id` (uuid, primary key)
      - `name` (text, unique) - Role name
      - `created_at` (timestamptz) - Creation timestamp

  2. Security
    - Enable RLS on `roles` table
    - Add policies for admin users to manage roles
    - Add policy for authenticated users to read roles

  3. Changes
    - Creates a dedicated table for storing available roles
    - Roles can be created independently of user assignment
*/

-- Create roles table
CREATE TABLE IF NOT EXISTS roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read roles
CREATE POLICY "Authenticated users can read roles"
  ON roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow authenticated users to insert roles (admin check should be done in app)
CREATE POLICY "Authenticated users can create roles"
  ON roles
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow authenticated users to delete roles
CREATE POLICY "Authenticated users can delete roles"
  ON roles
  FOR DELETE
  TO authenticated
  USING (true);

-- Insert default roles
INSERT INTO roles (name) VALUES
  ('admin'),
  ('manager'),
  ('chef'),
  ('staff')
ON CONFLICT (name) DO NOTHING;