/*
  # Add latest_review_date to dismissed_alerts

  ## Summary
  Updates the dismissed_alerts table to track which review was "current" when the user
  marked an alert as read. This allows new reviews to re-trigger alerts automatically
  — if a location receives a new low-scoring review after the user marked it as read,
  the alert will reappear.

  ## Changes
  - `dismissed_alerts` table: add `latest_review_date` column (text, nullable)
    - Stores the date of the most recent review at the time the user marked the alert as read
    - The app compares this against the location's current latest review date
    - If a newer review has arrived, the dismissal is ignored and the alert shows again

  ## Notes
  - Existing dismissed rows will have NULL for latest_review_date
  - NULL is treated as "always dismissed" for backwards compatibility during transition
    but the frontend logic will treat NULL as an old dismissal that gets re-evaluated
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'dismissed_alerts' AND column_name = 'latest_review_date'
  ) THEN
    ALTER TABLE dismissed_alerts ADD COLUMN latest_review_date text;
  END IF;
END $$;
