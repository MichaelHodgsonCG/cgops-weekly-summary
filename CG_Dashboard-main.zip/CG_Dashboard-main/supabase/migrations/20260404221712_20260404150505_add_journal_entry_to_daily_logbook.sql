/*
  # Add Journal Entry Field to Daily Logbook

  1. Changes
    - Add journal_entry column to daily_logbook table
    - This will store the journal/notes section from daily logbook emails

  2. Notes
    - Using text type to allow for long-form journal entries
    - Nullable field as not all reports may have journal entries
*/

-- Add journal_entry column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'daily_logbook' AND column_name = 'journal_entry'
  ) THEN
    ALTER TABLE daily_logbook ADD COLUMN journal_entry text;
  END IF;
END $$;