/*
  # Create Location Mappings Table

  1. New Tables
    - `location_mappings`
      - `id` (uuid, primary key) - Unique identifier
      - `source_name` (text, unique) - Name as it appears in emails/uploads
      - `canonical_location_id` (uuid) - Reference to locations table
      - `canonical_location_name` (text) - Name as it appears in locations table
      - `created_at` (timestamptz) - When mapping was created
      - `updated_at` (timestamptz) - When mapping was last updated

  2. Security
    - Enable RLS on `location_mappings` table
    - Add policies for authenticated users to read mappings
    - Add policies for admins to manage mappings

  3. Purpose
    - Normalize location names from different sources (OpenTable, uploads, etc.)
    - Handle variations like "Beertown - London White Oaks" vs "Beertown London White Oaks"
    - Prevent duplicate locations from being created
*/

CREATE TABLE IF NOT EXISTS location_mappings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_name text UNIQUE NOT NULL,
  canonical_location_id uuid REFERENCES locations(id) ON DELETE CASCADE,
  canonical_location_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE location_mappings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read location mappings"
  ON location_mappings FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can insert location mappings"
  ON location_mappings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update location mappings"
  ON location_mappings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete location mappings"
  ON location_mappings FOR DELETE
  TO authenticated
  USING (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_location_mappings_source_name ON location_mappings(source_name);
CREATE INDEX IF NOT EXISTS idx_location_mappings_canonical_id ON location_mappings(canonical_location_id);