/*
  # Create dismissed_alerts table

  Stores per-user dismissals of location alert badges on the Guest Feedback view.
  Each row means a specific user has chosen to clear the alert for a specific location.
  Dismissals are keyed by user_id (from the custom users table) and location_name.

  1. New Tables
    - `dismissed_alerts`
      - `id` (uuid, primary key)
      - `user_id` (text) - matches the custom auth user id
      - `location_name` (text) - the location whose alert was dismissed
      - `dismissed_at` (timestamptz) - when it was dismissed

  2. Security
    - Enable RLS
    - Allow anyone to read/insert/delete (matches existing permissive pattern in this app)
*/

CREATE TABLE IF NOT EXISTS dismissed_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  location_name text NOT NULL,
  dismissed_at timestamptz DEFAULT now(),
  UNIQUE (user_id, location_name)
);

ALTER TABLE dismissed_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view dismissed alerts"
  ON dismissed_alerts FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert dismissed alerts"
  ON dismissed_alerts FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can delete dismissed alerts"
  ON dismissed_alerts FOR DELETE
  USING (true);
