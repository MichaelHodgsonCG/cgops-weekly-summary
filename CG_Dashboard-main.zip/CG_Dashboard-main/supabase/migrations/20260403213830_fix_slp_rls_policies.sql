/*
  # Fix SLP RLS Policies for Public Access

  ## Changes
  Updates RLS policies on SLP tables to allow public access since auth is not set up.
  
  ## Modified Tables
  - `slp_reports` - Allow public insert and select
  - `slp_sales_data` - Allow public insert and select  
  - `slp_labor_data` - Allow public insert and select
  - `slp_promo_data` - Allow public insert and select
  
  ## Security Note
  This allows anyone to upload and view SLP reports. In production, you would want
  to enable authentication and restrict to authenticated users.
*/

-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Authenticated users can view all SLP reports" ON slp_reports;
DROP POLICY IF EXISTS "Authenticated users can insert SLP reports" ON slp_reports;
DROP POLICY IF EXISTS "Authenticated users can view all SLP sales data" ON slp_sales_data;
DROP POLICY IF EXISTS "Authenticated users can insert SLP sales data" ON slp_sales_data;
DROP POLICY IF EXISTS "Authenticated users can view all SLP labor data" ON slp_labor_data;
DROP POLICY IF EXISTS "Authenticated users can insert SLP labor data" ON slp_labor_data;
DROP POLICY IF EXISTS "Authenticated users can view all SLP promo data" ON slp_promo_data;
DROP POLICY IF EXISTS "Authenticated users can insert SLP promo data" ON slp_promo_data;

-- Create public access policies for slp_reports
CREATE POLICY "Anyone can view SLP reports"
  ON slp_reports FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert SLP reports"
  ON slp_reports FOR INSERT
  TO public
  WITH CHECK (true);

-- Create public access policies for slp_sales_data
CREATE POLICY "Anyone can view SLP sales data"
  ON slp_sales_data FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert SLP sales data"
  ON slp_sales_data FOR INSERT
  TO public
  WITH CHECK (true);

-- Create public access policies for slp_labor_data
CREATE POLICY "Anyone can view SLP labor data"
  ON slp_labor_data FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert SLP labor data"
  ON slp_labor_data FOR INSERT
  TO public
  WITH CHECK (true);

-- Create public access policies for slp_promo_data
CREATE POLICY "Anyone can view SLP promo data"
  ON slp_promo_data FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert SLP promo data"
  ON slp_promo_data FOR INSERT
  TO public
  WITH CHECK (true);
