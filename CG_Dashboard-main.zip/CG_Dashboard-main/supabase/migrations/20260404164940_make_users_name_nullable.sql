/*
  # Make users name field nullable

  1. Changes
    - Alter users.name column to allow NULL values
    - This allows restaurant users to be created without requiring a name
*/

ALTER TABLE users ALTER COLUMN name DROP NOT NULL;
