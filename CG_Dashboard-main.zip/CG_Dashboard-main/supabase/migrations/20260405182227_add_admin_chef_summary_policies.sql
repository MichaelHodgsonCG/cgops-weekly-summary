/*
  # Add Admin Policies for Chef Summaries

  1. Changes
    - Add INSERT policy for admins to create summaries for any location
    - Add UPDATE policy for admins to update summaries for any location
    
  2. Security
    - Policies check for admin role in users table
    - Allows admins to manage all chef summaries across all locations
*/

CREATE POLICY "Admins can create summaries for any location"
  ON weekly_chef_summary
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can update summaries for any location"
  ON weekly_chef_summary
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin'
    )
  );