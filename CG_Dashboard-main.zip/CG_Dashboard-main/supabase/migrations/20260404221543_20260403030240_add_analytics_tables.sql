/*
  # Enhanced Analytics Schema for Multi-Location Comparative Analysis

  1. New Tables
    - `location_metadata`
      - Enhanced location information including region, format, size
      - Market tier classification for peer comparisons
      - Opening date for tenure-based analysis
    
    - `performance_benchmarks`
      - Company-wide performance targets by metric and location tier
      - Rolling 13-week averages as dynamic benchmarks
      - Best-in-class historical performance markers
    
    - `location_rankings`
      - Cached weekly rankings for four priority metrics
      - Composite performance scores with weighted priorities
      - Week-over-week ranking movement tracking
    
    - `location_groups`
      - Regional and custom groupings for comparison
      - Flexible cohort definitions
    
    - `location_group_members`
      - Many-to-many relationship between locations and groups
    
    - `performance_alerts`
      - Threshold-based alerts for Food Cost %, Labor %, EBITDA variance
      - Alert severity and acknowledgment tracking
      - Historical alert log

  2. Security
    - Enable RLS on all new tables
    - Public access policies for analytics data
    
  3. Indexes
    - Optimized for comparison queries and ranking lookups
    - Date-based indexes for time series analysis
*/

-- Add metadata columns to locations table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations' AND column_name = 'region'
  ) THEN
    ALTER TABLE locations ADD COLUMN region text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations' AND column_name = 'format_type'
  ) THEN
    ALTER TABLE locations ADD COLUMN format_type text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations' AND column_name = 'square_footage'
  ) THEN
    ALTER TABLE locations ADD COLUMN square_footage integer;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations' AND column_name = 'seating_capacity'
  ) THEN
    ALTER TABLE locations ADD COLUMN seating_capacity integer;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations' AND column_name = 'opening_date'
  ) THEN
    ALTER TABLE locations ADD COLUMN opening_date date;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations' AND column_name = 'market_tier'
  ) THEN
    ALTER TABLE locations ADD COLUMN market_tier text;
  END IF;
END $$;

-- Create performance_benchmarks table
CREATE TABLE IF NOT EXISTS performance_benchmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  metric_name text NOT NULL,
  market_tier text,
  target_value numeric NOT NULL,
  rolling_13wk_avg numeric,
  best_in_class numeric,
  effective_date date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create location_rankings table
CREATE TABLE IF NOT EXISTS location_rankings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  week_ending_date date NOT NULL,
  food_sales_rank integer,
  food_sales_value numeric,
  food_cost_pct_rank integer,
  food_cost_pct_value numeric,
  labor_pct_rank integer,
  labor_pct_value numeric,
  ebitda_budget_var_rank integer,
  ebitda_budget_var_value numeric,
  composite_score numeric,
  rank_change_from_prior_week integer,
  created_at timestamptz DEFAULT now(),
  UNIQUE(location_id, week_ending_date)
);

-- Create location_groups table
CREATE TABLE IF NOT EXISTS location_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  group_type text DEFAULT 'custom',
  created_at timestamptz DEFAULT now()
);

-- Create location_group_members table
CREATE TABLE IF NOT EXISTS location_group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES location_groups(id) ON DELETE CASCADE,
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(group_id, location_id)
);

-- Create performance_alerts table
CREATE TABLE IF NOT EXISTS performance_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  week_ending_date date NOT NULL,
  alert_type text NOT NULL,
  metric_name text NOT NULL,
  threshold_value numeric,
  actual_value numeric,
  severity text DEFAULT 'medium',
  message text NOT NULL,
  acknowledged boolean DEFAULT false,
  acknowledged_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on new tables
ALTER TABLE performance_benchmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE location_rankings ENABLE ROW LEVEL SECURITY;
ALTER TABLE location_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE location_group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_alerts ENABLE ROW LEVEL SECURITY;

-- Create policies for performance_benchmarks
CREATE POLICY "Anyone can read benchmarks"
  ON performance_benchmarks FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert benchmarks"
  ON performance_benchmarks FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update benchmarks"
  ON performance_benchmarks FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Create policies for location_rankings
CREATE POLICY "Anyone can read rankings"
  ON location_rankings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert rankings"
  ON location_rankings FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update rankings"
  ON location_rankings FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete rankings"
  ON location_rankings FOR DELETE
  TO public
  USING (true);

-- Create policies for location_groups
CREATE POLICY "Anyone can read groups"
  ON location_groups FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert groups"
  ON location_groups FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update groups"
  ON location_groups FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete groups"
  ON location_groups FOR DELETE
  TO public
  USING (true);

-- Create policies for location_group_members
CREATE POLICY "Anyone can read group members"
  ON location_group_members FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert group members"
  ON location_group_members FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can delete group members"
  ON location_group_members FOR DELETE
  TO public
  USING (true);

-- Create policies for performance_alerts
CREATE POLICY "Anyone can read alerts"
  ON performance_alerts FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert alerts"
  ON performance_alerts FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update alerts"
  ON performance_alerts FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete alerts"
  ON performance_alerts FOR DELETE
  TO public
  USING (true);

-- Create indexes for performance queries
CREATE INDEX IF NOT EXISTS idx_benchmarks_metric 
  ON performance_benchmarks(metric_name, effective_date DESC);

CREATE INDEX IF NOT EXISTS idx_rankings_location_date 
  ON location_rankings(location_id, week_ending_date DESC);

CREATE INDEX IF NOT EXISTS idx_rankings_week_date 
  ON location_rankings(week_ending_date DESC);

CREATE INDEX IF NOT EXISTS idx_group_members_group 
  ON location_group_members(group_id);

CREATE INDEX IF NOT EXISTS idx_group_members_location 
  ON location_group_members(location_id);

CREATE INDEX IF NOT EXISTS idx_alerts_location_date 
  ON performance_alerts(location_id, week_ending_date DESC);

CREATE INDEX IF NOT EXISTS idx_alerts_acknowledged 
  ON performance_alerts(acknowledged, week_ending_date DESC);

-- Insert default regional groups
INSERT INTO location_groups (name, description, group_type) VALUES
  ('Central Region', 'Central Ontario locations', 'regional'),
  ('Eastern Region', 'Eastern Ontario locations', 'regional'),
  ('Western Region', 'Western Ontario locations', 'regional')
ON CONFLICT DO NOTHING;

-- Update locations with regional data
UPDATE locations SET region = 'Central', market_tier = 'A' WHERE code = 'KINGWEST';
UPDATE locations SET region = 'Central', market_tier = 'A' WHERE code = 'ETOBICOKE';
UPDATE locations SET region = 'Central', market_tier = 'A' WHERE code = 'YORK';
UPDATE locations SET region = 'Central', market_tier = 'B' WHERE code = 'VAUGHAN';
UPDATE locations SET region = 'Central', market_tier = 'B' WHERE code = 'MARKHAM';
UPDATE locations SET region = 'Central', market_tier = 'B' WHERE code = 'MISSISSAUGA';
UPDATE locations SET region = 'Central', market_tier = 'B' WHERE code = 'BURLINGTON';
UPDATE locations SET region = 'Central', market_tier = 'B' WHERE code = 'OAKVILLE';
UPDATE locations SET region = 'Eastern', market_tier = 'A' WHERE code = 'OTTAWA';
UPDATE locations SET region = 'Eastern', market_tier = 'B' WHERE code = 'SCARBOROUGH';
UPDATE locations SET region = 'Eastern', market_tier = 'B' WHERE code = 'PICKERING';
UPDATE locations SET region = 'Eastern', market_tier = 'B' WHERE code = 'WHITBY';
UPDATE locations SET region = 'Western', market_tier = 'A' WHERE code = 'LONDON';
UPDATE locations SET region = 'Western', market_tier = 'B' WHERE code = 'WATERLOO';
UPDATE locations SET region = 'Western', market_tier = 'B' WHERE code = 'HAMILTON';
UPDATE locations SET region = 'Central', market_tier = 'B' WHERE code = 'BARRIE';