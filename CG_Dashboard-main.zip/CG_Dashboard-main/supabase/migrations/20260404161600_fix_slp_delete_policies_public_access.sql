/*
  # Fix SLP DELETE policies for public access

  ## Overview
  Updates DELETE policies to allow public access (anon users) to match the existing SELECT and INSERT policies.

  ## Changes
  - Drop existing authenticated-only DELETE policies
  - Create new public DELETE policies for all SLP tables

  ## Security
  All policies now allow public (anon) access to match the SELECT and INSERT policies.
*/

-- Drop existing DELETE policies
DROP POLICY IF EXISTS "Authenticated users can delete SLP reports" ON slp_reports;
DROP POLICY IF EXISTS "Authenticated users can delete SLP sales data" ON slp_sales_data;
DROP POLICY IF EXISTS "Authenticated users can delete SLP labor data" ON slp_labor_data;
DROP POLICY IF EXISTS "Authenticated users can delete SLP promo data" ON slp_promo_data;

-- Create new public DELETE policies
CREATE POLICY "Anyone can delete SLP reports"
  ON slp_reports FOR DELETE
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can delete SLP sales data"
  ON slp_sales_data FOR DELETE
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can delete SLP labor data"
  ON slp_labor_data FOR DELETE
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can delete SLP promo data"
  ON slp_promo_data FOR DELETE
  TO anon, authenticated
  USING (true);