/*
  # Add admin access policies for raw_emails table

  1. Security Changes
    - Add RLS policy for admin users to read raw_emails
    - Allows administrators to view and process emails through the Email Processor UI
*/

CREATE POLICY "Admins can view raw emails"
  ON raw_emails
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  );
