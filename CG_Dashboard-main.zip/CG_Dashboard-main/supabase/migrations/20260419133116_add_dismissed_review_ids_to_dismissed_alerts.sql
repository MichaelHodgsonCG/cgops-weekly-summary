/*
  # Add dismissed_review_ids to dismissed_alerts

  ## Summary
  Replaces the date-based dismissal comparison with a per-review-ID approach.
  When a user marks an alert as read, the specific IDs of the low-scoring reviews
  that existed at that moment are stored. An alert is only considered "read" when
  ALL current low-scoring reviews for a location are in the user's dismissed set.
  A brand-new review (with a new ID) will correctly re-trigger the alert.

  ## Changes
  - `dismissed_alerts` table: add `dismissed_review_ids` column (text array, not null, default empty)
    - Stores the UUIDs of individual guest_feedback rows that were acknowledged
    - New reviews arriving after dismissal have different IDs, so they re-trigger alerts
    - The `latest_review_date` column is kept for backwards compatibility but is no longer
      used as the primary dismissal signal

  ## Notes
  - Existing dismissed rows will have an empty array, which means those locations will
    re-show as alerts on the next load. This is the correct behaviour — users should
    acknowledge the actual reviews that caused the alert.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'dismissed_alerts' AND column_name = 'dismissed_review_ids'
  ) THEN
    ALTER TABLE dismissed_alerts ADD COLUMN dismissed_review_ids text[] NOT NULL DEFAULT '{}';
  END IF;
END $$;
