/*
  # Allow anonymous update and delete for weekly chef summaries
  
  1. Changes
    - Add policy to allow anon role to update chef summaries
    - Add policy to allow anon role to delete chef summaries
    - This ensures anon can fully manage the data during import
  
  2. Security
    - RLS remains enabled
    - Policies added for anon role for update and delete operations
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'weekly_chef_summary' 
    AND policyname = 'Allow anon to update chef summaries'
  ) THEN
    CREATE POLICY "Allow anon to update chef summaries"
      ON weekly_chef_summary
      FOR UPDATE
      TO anon
      USING (true)
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'weekly_chef_summary' 
    AND policyname = 'Allow anon to delete chef summaries'
  ) THEN
    CREATE POLICY "Allow anon to delete chef summaries"
      ON weekly_chef_summary
      FOR DELETE
      TO anon
      USING (true);
  END IF;
END $$;
