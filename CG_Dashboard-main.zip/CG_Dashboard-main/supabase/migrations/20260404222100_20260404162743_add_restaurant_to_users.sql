/*
  # Add restaurant column to users table

  1. Changes
    - Add restaurant column to users table to specify which restaurant a user belongs to
    - This allows filtering data by restaurant for non-admin users

  2. Notes
    - Column is nullable (NULL means the user can see all restaurants - admin)
    - For regular users, set this to a specific location code (e.g., 'BARRIE', 'BURLINGTON')
*/

-- Add restaurant column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'restaurant'
  ) THEN
    ALTER TABLE users ADD COLUMN restaurant text;
  END IF;
END $$;