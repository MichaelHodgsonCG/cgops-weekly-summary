/*
  # Update Daily Logbook RLS Policies for Public Access

  1. Changes
    - Drop existing restrictive RLS policies on daily_logbook table
    - Add public SELECT policy to allow unauthenticated users to view data
    - Keep INSERT and UPDATE policies for authenticated users only

  2. Security
    - Public read access allows the UI to display logs without authentication
    - Write operations still require authentication for data integrity
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Authenticated users can view daily logbook" ON daily_logbook;
DROP POLICY IF EXISTS "Authenticated users can insert daily logbook" ON daily_logbook;
DROP POLICY IF EXISTS "Authenticated users can update daily logbook" ON daily_logbook;

-- Create new policies with public read access
CREATE POLICY "Anyone can view daily logbook"
  ON daily_logbook
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert daily logbook"
  ON daily_logbook
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update daily logbook"
  ON daily_logbook
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);