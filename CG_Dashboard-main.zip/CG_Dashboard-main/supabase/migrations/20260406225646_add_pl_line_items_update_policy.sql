/*
  # Add UPDATE policy to pl_line_items table

  1. Security Changes
    - Add policy to allow anyone to update pl_line_items records
    - This is needed for the Labour Adjustments feature to work properly
*/

CREATE POLICY "Anyone can update pl_line_items"
  ON pl_line_items
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);
