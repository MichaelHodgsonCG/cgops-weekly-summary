/*
  # Add management opportunities to daily_insights

  1. Changes
    - Add `management_opportunities_json` column to store management coaching opportunities
    - Add `management_opportunities_count` column to track the count
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'daily_insights' AND column_name = 'management_opportunities_json'
  ) THEN
    ALTER TABLE daily_insights ADD COLUMN management_opportunities_json jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'daily_insights' AND column_name = 'management_opportunities_count'
  ) THEN
    ALTER TABLE daily_insights ADD COLUMN management_opportunities_count integer DEFAULT 0;
  END IF;
END $$;
