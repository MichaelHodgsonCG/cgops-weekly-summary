/*
  # Fix Fiscal Calendar RLS Policies

  1. Changes
    - Drop existing policies that are too restrictive
    - Add new policies that allow authenticated users full access
    - Allow anonymous users read-only access for public dashboards
  
  2. Security
    - Authenticated users can insert, update, and delete fiscal calendar entries
    - Anonymous users can only read fiscal calendar data
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can read fiscal calendar" ON fiscal_calendar;
DROP POLICY IF EXISTS "Public can read fiscal calendar" ON fiscal_calendar;
DROP POLICY IF EXISTS "Authenticated users can insert fiscal calendar" ON fiscal_calendar;
DROP POLICY IF EXISTS "Authenticated users can update fiscal calendar" ON fiscal_calendar;
DROP POLICY IF EXISTS "Authenticated users can delete fiscal calendar" ON fiscal_calendar;

-- Allow authenticated users to read all fiscal calendar entries
CREATE POLICY "Authenticated users can read fiscal calendar"
  ON fiscal_calendar
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow anonymous users to read fiscal calendar (for public dashboards)
CREATE POLICY "Anonymous users can read fiscal calendar"
  ON fiscal_calendar
  FOR SELECT
  TO anon
  USING (true);

-- Allow authenticated users to insert fiscal calendar entries
CREATE POLICY "Authenticated users can insert fiscal calendar"
  ON fiscal_calendar
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow authenticated users to update fiscal calendar entries
CREATE POLICY "Authenticated users can update fiscal calendar"
  ON fiscal_calendar
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Allow authenticated users to delete fiscal calendar entries
CREATE POLICY "Authenticated users can delete fiscal calendar"
  ON fiscal_calendar
  FOR DELETE
  TO authenticated
  USING (true);
