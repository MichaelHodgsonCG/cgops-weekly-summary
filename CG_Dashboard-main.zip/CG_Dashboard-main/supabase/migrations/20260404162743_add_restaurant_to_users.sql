/*
  # Add restaurant column to users table

  1. Changes
    - Add `restaurant` column to `users` table
    - Column is nullable to support admin users without specific restaurant assignment
    - Column references location names from the locations table
  
  2. Notes
    - Existing users (like admins) can have NULL restaurant values
    - Restaurant managers/staff will have their specific location assigned
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'restaurant'
  ) THEN
    ALTER TABLE users ADD COLUMN restaurant text;
  END IF;
END $$;