/*
  # Add processing_duration_ms to daily_insights

  1. Changes
    - Add `processing_duration_ms` column to `daily_insights` table to track AI processing time
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'daily_insights' AND column_name = 'processing_duration_ms'
  ) THEN
    ALTER TABLE daily_insights ADD COLUMN processing_duration_ms integer;
  END IF;
END $$;
