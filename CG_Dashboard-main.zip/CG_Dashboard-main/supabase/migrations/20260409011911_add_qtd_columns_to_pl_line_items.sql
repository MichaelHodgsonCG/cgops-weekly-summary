/*
  # Add QTD (Quarter-to-Date) columns to pl_line_items

  ## Summary
  Adds quarter-to-date financial columns to support the "Need to Save" calculation logic
  in the Weekly Chef Summary. QTD data is populated at upload time by summing period-level
  actuals and budgets across all periods within the current fiscal quarter.

  ## Quarter Mapping
  - Q1 = Periods 1-3
  - Q2 = Periods 4-6
  - Q3 = Periods 7-9
  - Q4 = Periods 10-13

  ## New Columns on pl_line_items
  - qtd_actual: Quarter-to-date actual dollar amount
  - qtd_actual_pct: Quarter-to-date actual percentage
  - qtd_budget: Quarter-to-date budget dollar amount
  - qtd_budget_pct: Quarter-to-date budget percentage

  ## Notes
  - All columns are nullable since they will only be populated as period data accumulates
  - No data is backfilled; new uploads will populate these fields going forward
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pl_line_items' AND column_name = 'qtd_actual'
  ) THEN
    ALTER TABLE pl_line_items ADD COLUMN qtd_actual numeric;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pl_line_items' AND column_name = 'qtd_actual_pct'
  ) THEN
    ALTER TABLE pl_line_items ADD COLUMN qtd_actual_pct numeric;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pl_line_items' AND column_name = 'qtd_budget'
  ) THEN
    ALTER TABLE pl_line_items ADD COLUMN qtd_budget numeric;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pl_line_items' AND column_name = 'qtd_budget_pct'
  ) THEN
    ALTER TABLE pl_line_items ADD COLUMN qtd_budget_pct numeric;
  END IF;
END $$;
