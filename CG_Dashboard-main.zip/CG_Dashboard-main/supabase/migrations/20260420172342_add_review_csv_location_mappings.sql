/*
  # Add Location Mappings for Weekly Review CSV Import

  ## Summary
  Adds three location mappings to support importing weekly review CSV files for
  restaurants that were previously receiving weekly reports instead of daily ones.

  ## New Mappings
  - "Beertown - Waterloo" → "Beertown Waterloo"
  - "Beertown - Barrie" → "Beertown Barrie"
  - "Beertown - Toronto" → "Beertown Toronto"

  These mappings follow the existing pattern where CSV/email source names (with dashes
  and spaces) are normalized to canonical location names used in the database.
*/

INSERT INTO location_mappings (source_name, canonical_location_name)
VALUES
  ('Beertown - Waterloo', 'Beertown Waterloo'),
  ('Beertown - Barrie', 'Beertown Barrie'),
  ('Beertown - Toronto', 'Beertown Toronto')
ON CONFLICT DO NOTHING;
