/*
  # Create Permissions System

  1. New Tables
    - `permissions`
      - `id` (uuid, primary key)
      - `name` (text, unique) - Human-readable name (e.g., "View Dashboard")
      - `code` (text, unique) - System code (e.g., "dashboard.view")
      - `description` (text) - What this permission allows
      - `category` (text) - Grouping (e.g., "Reports", "Admin", "Data")
      - `created_at` (timestamptz)
    
    - `role_permissions`
      - `id` (uuid, primary key)
      - `role_id` (uuid, foreign key to roles)
      - `permission_id` (uuid, foreign key to permissions)
      - `created_at` (timestamptz)
      - Unique constraint on (role_id, permission_id)

  2. Security
    - Enable RLS on both tables
    - Allow authenticated users to read permissions
    - Allow authenticated users to read role_permissions
    - Only authenticated users can manage (for now, will add admin checks later)

  3. Initial Permissions
    - Dashboard and reporting views
    - Data management (uploads, locations)
    - Admin functions (users, roles, permissions)
*/

-- Create permissions table
CREATE TABLE IF NOT EXISTS permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  code text UNIQUE NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create role_permissions junction table
CREATE TABLE IF NOT EXISTS role_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id uuid NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(role_id, permission_id)
);

-- Enable RLS
ALTER TABLE permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_permissions ENABLE ROW LEVEL SECURITY;

-- Permissions policies (allow all authenticated users to read for now)
CREATE POLICY "Anyone can read permissions"
  ON permissions FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can manage permissions"
  ON permissions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update permissions"
  ON permissions FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete permissions"
  ON permissions FOR DELETE
  TO authenticated
  USING (true);

-- Role permissions policies
CREATE POLICY "Anyone can read role permissions"
  ON role_permissions FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can assign permissions"
  ON role_permissions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can remove permissions"
  ON role_permissions FOR DELETE
  TO authenticated
  USING (true);

-- Insert default permissions
INSERT INTO permissions (name, code, description, category) VALUES
  -- Dashboard & Reports
  ('View Dashboard', 'dashboard.view', 'Access main dashboard with P&L summaries', 'Reports'),
  ('View Portfolio', 'portfolio.view', 'View portfolio-wide metrics and summaries', 'Reports'),
  ('View Rankings', 'rankings.view', 'View location performance rankings', 'Reports'),
  ('View Trends', 'trends.view', 'View trend analysis across periods', 'Reports'),
  ('View Comparisons', 'comparison.view', 'Compare multiple locations', 'Reports'),
  ('View Alerts', 'alerts.view', 'View automated alerts and notifications', 'Reports'),
  ('View SLP Data', 'slp.view', 'View Store Level P&L data', 'Reports'),
  ('View Guest Feedback', 'feedback.view', 'View guest feedback reports', 'Reports'),
  
  -- Data Management
  ('Upload P&L Data', 'pl.upload', 'Upload P&L files for locations', 'Data'),
  ('Upload SLP Data', 'slp.upload', 'Upload Store Level P&L data', 'Data'),
  ('Process Emails', 'email.process', 'Process incoming email data', 'Data'),
  ('View Logs', 'logs.view', 'View system logs and data processing history', 'Data'),
  ('Manage Locations', 'locations.manage', 'Create, edit, and delete locations', 'Data'),
  ('Manage Location Mappings', 'mappings.manage', 'Manage location name mappings', 'Data'),
  ('Manage Fiscal Calendar', 'fiscal.manage', 'Manage fiscal calendar periods', 'Data'),
  
  -- Chef Summaries
  ('View Chef Summaries', 'chef.view', 'View weekly chef summaries', 'Reports'),
  ('Manage Chef Summaries', 'chef.manage', 'Create and edit chef summaries', 'Data'),
  
  -- Admin Functions
  ('Manage Users', 'users.manage', 'Create, edit, and delete users', 'Admin'),
  ('Manage Roles', 'roles.manage', 'Create, edit, and delete roles', 'Admin'),
  ('Manage Permissions', 'permissions.manage', 'Assign permissions to roles', 'Admin')
ON CONFLICT (code) DO NOTHING;