/*
  # Allow anonymous users to read raw_emails
  
  1. Changes
    - Add policy allowing anon role to read raw_emails
    - This is required because the app uses custom auth (localStorage) instead of Supabase Auth
    - The Supabase client operates with anon key for all queries
  
  2. Security
    - Anon (public) can read emails
    - Anon (public) can insert emails (webhook endpoint)
    - Custom app-level auth controls which users can access the UI
*/

-- Allow anon role to read emails
CREATE POLICY "Anonymous users can view raw emails"
  ON raw_emails
  FOR SELECT
  TO anon
  USING (true);
