/*
  # Create SLP (Daily Labor Report) Tables

  ## Overview
  Creates tables to store daily labor performance data for all locations across multiple departments.

  ## New Tables
  
  ### `slp_reports`
  Main table for tracking report uploads
  - `id` (uuid, primary key)
  - `report_date` (date) - The date this report represents
  - `uploaded_at` (timestamptz) - When the report was uploaded
  - `uploaded_by` (uuid) - User who uploaded the report
  - `file_name` (text) - Original filename
  
  ### `slp_sales_data`
  Sales metrics for each location
  - `id` (uuid, primary key)
  - `report_id` (uuid, foreign key to slp_reports)
  - `location_name` (text) - Location name
  - `total_daily_sales` (numeric)
  - `total_wtd_sales` (numeric)
  - `daily_sales_vs_projections` (numeric)
  - `wtd_sales_vs_projections` (numeric)
  - `daily_sales_vs_last_year` (numeric)
  - `wtd_sales_vs_last_year` (numeric)
  - `wtd_sales_vs_last_year_pct` (numeric)

  ### `slp_labor_data`
  Labor metrics by department for each location
  - `id` (uuid, primary key)
  - `report_id` (uuid, foreign key to slp_reports)
  - `location_name` (text)
  - `department` (text) - BOH, FOH, Manager, etc.
  - `labour_budget_pct` (numeric)
  - `daily_labour_actual_pct` (numeric)
  - `wtd_labour_actual_pct` (numeric)
  - `daily_labour_projection_pct` (numeric)
  - `full_week_labour_projection_pct` (numeric)
  - `daily_labour_dollars_vs_projections` (numeric)
  - `wtd_labour_dollars_vs_projections` (numeric)
  - `wtd_labour_pct_vs_budget_pct` (numeric)
  - `wtd_labour_dollars_vs_sales` (numeric)

  ### `slp_promo_data`
  Promotional data for each location
  - `id` (uuid, primary key)
  - `report_id` (uuid, foreign key to slp_reports)
  - `location_name` (text)
  - `relationship_dollars` (numeric)
  - `substandard_dollars` (numeric)
  - `total_promo_pct` (numeric)

  ## Security
  - Enable RLS on all tables
  - Authenticated users can view all SLP data
  - Authenticated users can insert new reports and data
*/

-- Create slp_reports table
CREATE TABLE IF NOT EXISTS slp_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_date date NOT NULL,
  uploaded_at timestamptz DEFAULT now(),
  uploaded_by uuid REFERENCES auth.users(id),
  file_name text,
  created_at timestamptz DEFAULT now()
);

-- Create slp_sales_data table
CREATE TABLE IF NOT EXISTS slp_sales_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid REFERENCES slp_reports(id) ON DELETE CASCADE NOT NULL,
  location_name text NOT NULL,
  total_daily_sales numeric,
  total_wtd_sales numeric,
  daily_sales_vs_projections numeric,
  wtd_sales_vs_projections numeric,
  daily_sales_vs_last_year numeric,
  wtd_sales_vs_last_year numeric,
  wtd_sales_vs_last_year_pct numeric,
  created_at timestamptz DEFAULT now()
);

-- Create slp_labor_data table
CREATE TABLE IF NOT EXISTS slp_labor_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid REFERENCES slp_reports(id) ON DELETE CASCADE NOT NULL,
  location_name text NOT NULL,
  department text NOT NULL,
  labour_budget_pct numeric,
  daily_labour_actual_pct numeric,
  wtd_labour_actual_pct numeric,
  daily_labour_projection_pct numeric,
  full_week_labour_projection_pct numeric,
  daily_labour_dollars_vs_projections numeric,
  wtd_labour_dollars_vs_projections numeric,
  wtd_labour_pct_vs_budget_pct numeric,
  wtd_labour_dollars_vs_sales numeric,
  created_at timestamptz DEFAULT now()
);

-- Create slp_promo_data table
CREATE TABLE IF NOT EXISTS slp_promo_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid REFERENCES slp_reports(id) ON DELETE CASCADE NOT NULL,
  location_name text NOT NULL,
  relationship_dollars numeric,
  substandard_dollars numeric,
  total_promo_pct numeric,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE slp_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE slp_sales_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE slp_labor_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE slp_promo_data ENABLE ROW LEVEL SECURITY;

-- RLS Policies for slp_reports
CREATE POLICY "Authenticated users can view all SLP reports"
  ON slp_reports FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert SLP reports"
  ON slp_reports FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for slp_sales_data
CREATE POLICY "Authenticated users can view all SLP sales data"
  ON slp_sales_data FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert SLP sales data"
  ON slp_sales_data FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for slp_labor_data
CREATE POLICY "Authenticated users can view all SLP labor data"
  ON slp_labor_data FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert SLP labor data"
  ON slp_labor_data FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for slp_promo_data
CREATE POLICY "Authenticated users can view all SLP promo data"
  ON slp_promo_data FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert SLP promo data"
  ON slp_promo_data FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_slp_sales_data_report_id ON slp_sales_data(report_id);
CREATE INDEX IF NOT EXISTS idx_slp_labor_data_report_id ON slp_labor_data(report_id);
CREATE INDEX IF NOT EXISTS idx_slp_labor_data_department ON slp_labor_data(department);
CREATE INDEX IF NOT EXISTS idx_slp_promo_data_report_id ON slp_promo_data(report_id);
CREATE INDEX IF NOT EXISTS idx_slp_reports_date ON slp_reports(report_date DESC);