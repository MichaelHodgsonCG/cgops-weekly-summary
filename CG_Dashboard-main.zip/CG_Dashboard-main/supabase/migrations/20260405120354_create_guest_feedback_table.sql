/*
  # Create Guest Feedback Table

  1. New Tables
    - `guest_feedback`
      - `id` (uuid, primary key)
      - `location_name` (text) - Restaurant location name
      - `review_date` (date) - Date of the review
      - `report_date` (date) - Date of the report
      - `reviewer_name` (text) - Name of the reviewer
      - `review_source` (text) - Source (Google, OpenTable, etc.)
      - `overall_rating` (numeric) - Overall rating score
      - `food_rating` (numeric, nullable) - Food rating
      - `service_rating` (numeric, nullable) - Service rating
      - `ambience_rating` (numeric, nullable) - Ambience rating
      - `value_rating` (numeric, nullable) - Value rating
      - `review_text` (text) - Full review text
      - `visit_date` (timestamptz, nullable) - Date of the visit
      - `raw_email_id` (uuid, nullable) - Reference to raw_emails
      - `created_at` (timestamptz) - Record creation timestamp
      - `updated_at` (timestamptz) - Record update timestamp

  2. Security
    - Enable RLS on `guest_feedback` table
    - Add policies for public read access (since this is internal tool)
    - Add policies for authenticated users to manage feedback

  3. Indexes
    - Index on location_name for filtering
    - Index on review_date for sorting
    - Composite index on location_name and review_date
*/

CREATE TABLE IF NOT EXISTS guest_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_name text NOT NULL,
  review_date date NOT NULL,
  report_date date NOT NULL,
  reviewer_name text,
  review_source text NOT NULL,
  overall_rating numeric(3,2),
  food_rating numeric(3,2),
  service_rating numeric(3,2),
  ambience_rating numeric(3,2),
  value_rating numeric(3,2),
  review_text text,
  visit_date timestamptz,
  raw_email_id uuid REFERENCES raw_emails(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(location_name, reviewer_name, review_date, review_source)
);

CREATE INDEX IF NOT EXISTS idx_guest_feedback_location ON guest_feedback(location_name);
CREATE INDEX IF NOT EXISTS idx_guest_feedback_review_date ON guest_feedback(review_date DESC);
CREATE INDEX IF NOT EXISTS idx_guest_feedback_location_date ON guest_feedback(location_name, review_date DESC);

ALTER TABLE guest_feedback ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to guest_feedback"
  ON guest_feedback
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public insert to guest_feedback"
  ON guest_feedback
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public update to guest_feedback"
  ON guest_feedback
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public delete from guest_feedback"
  ON guest_feedback
  FOR DELETE
  TO public
  USING (true);