/*
  # Create raw_emails table for Phase 0

  1. New Tables
    - `raw_emails`
      - `id` (uuid, primary key)
      - `received_at` (timestamptz) - When email arrived at CloudMailin
      - `subject` (text) - Email subject line
      - `from_email` (text) - Sender email address
      - `to_email` (text) - Recipient email address (CloudMailin inbox)
      - `body_plain` (text) - Plain text email body
      - `body_html` (text, nullable) - HTML email body if present
      - `raw_json` (jsonb) - Complete webhook payload from CloudMailin
      - `created_at` (timestamptz) - Database insertion timestamp

  2. Indexes
    - Index on `received_at` for chronological queries
    - Index on `from_email` for sender filtering

  3. Security
    - Enable RLS on `raw_emails` table
    - Add policy for authenticated users to view all emails
    - Add policy for public webhook to insert emails (anon role)

  ## Notes
  - No parsing or extraction logic yet
  - No location foreign keys yet
  - No structured data fields yet
  - Complete email content preserved for Phase 1 parser development
*/

-- Create raw_emails table
CREATE TABLE IF NOT EXISTS raw_emails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  received_at timestamptz DEFAULT now(),
  subject text NOT NULL DEFAULT '',
  from_email text NOT NULL DEFAULT '',
  to_email text NOT NULL DEFAULT '',
  body_plain text DEFAULT '',
  body_html text,
  raw_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Add indexes for common queries
CREATE INDEX IF NOT EXISTS idx_raw_emails_received_at ON raw_emails(received_at DESC);
CREATE INDEX IF NOT EXISTS idx_raw_emails_from_email ON raw_emails(from_email);

-- Enable RLS
ALTER TABLE raw_emails ENABLE ROW LEVEL SECURITY;

-- Policy: Authenticated users can view all emails
CREATE POLICY "Authenticated users can view all emails"
  ON raw_emails
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy: Allow anon (webhook) to insert emails
CREATE POLICY "Webhooks can insert emails"
  ON raw_emails
  FOR INSERT
  TO anon
  WITH CHECK (true);