/*
  # Create users table with PIN authentication

  ## Overview
  Creates a users table for PIN-based authentication system.

  ## New Tables
  - `users`
    - `id` (uuid, primary key) - Unique identifier for each user
    - `name` (text) - User's full name
    - `pin` (text) - 6-digit PIN for authentication
    - `role` (text) - User role (admin or user)
    - `created_at` (timestamptz) - When the user was created

  ## Security
  - Enable RLS on users table
  - Anyone can read users (needed for login verification)
  - Only authenticated users can insert/update users

  ## Initial Data
  - Creates initial admin user: Michael Hodgson with PIN 179321
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  pin text NOT NULL UNIQUE,
  role text NOT NULL DEFAULT 'user',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Anyone can read users (needed for login)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'users' AND policyname = 'Anyone can view users'
  ) THEN
    CREATE POLICY "Anyone can view users"
      ON users FOR SELECT
      TO anon, authenticated
      USING (true);
  END IF;
END $$;

-- Anyone can insert users (for now, will be restricted later)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'users' AND policyname = 'Anyone can insert users'
  ) THEN
    CREATE POLICY "Anyone can insert users"
      ON users FOR INSERT
      TO anon, authenticated
      WITH CHECK (true);
  END IF;
END $$;

-- Anyone can update users (for now, will be restricted later)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'users' AND policyname = 'Anyone can update users'
  ) THEN
    CREATE POLICY "Anyone can update users"
      ON users FOR UPDATE
      TO anon, authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Insert initial admin user
INSERT INTO users (name, pin, role)
VALUES ('Michael Hodgson', '179321', 'admin')
ON CONFLICT (pin) DO NOTHING;