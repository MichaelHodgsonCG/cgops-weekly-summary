/*
  # Merge "Sole Restaurant" into "Sole" in guest_feedback

  ## Summary
  There are two variations of the same restaurant appearing in guest feedback:
  - "Sole" (the canonical name matching the locations table)
  - "Sole Restaurant" (an alternate name used by some feedback imports)

  ## Changes
  1. Updates all guest_feedback rows with location_name = 'Sole Restaurant' to 'Sole'
  2. Inserts a location mapping so future imports of "Sole Restaurant" resolve to "Sole"
*/

UPDATE guest_feedback
SET location_name = 'Sole'
WHERE location_name = 'Sole Restaurant';

INSERT INTO location_mappings (source_name, canonical_location_id, canonical_location_name)
SELECT 'Sole Restaurant', id, 'Sole'
FROM locations
WHERE name = 'Sole'
ON CONFLICT (source_name) DO UPDATE
  SET canonical_location_id = EXCLUDED.canonical_location_id,
      canonical_location_name = EXCLUDED.canonical_location_name;
