/*
  # Create Weekly Chef Summary Table

  1. New Tables
    - `weekly_chef_summary`
      - `id` (uuid, primary key)
      - `location_id` (uuid, foreign key to locations)
      - `week_number` (integer)
      - `period_number` (integer)
      - `fiscal_year` (integer)
      - All performance, budget, labour, and operational metrics
      - Text summaries and team data
      - Feature items and hiring records (as JSONB)
      
  2. Security
    - Enable RLS on `weekly_chef_summary` table
    - Add policies for location-based access control
    - Add admin access policy
*/

CREATE TABLE IF NOT EXISTS weekly_chef_summary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid REFERENCES locations(id) ON DELETE CASCADE NOT NULL,
  week_number integer NOT NULL,
  period_number integer NOT NULL,
  fiscal_year integer NOT NULL DEFAULT 2026,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  budget_food_cost_pct numeric(5,2) DEFAULT 0,
  actual_food_cost_pct numeric(5,2) DEFAULT 0,
  fc_variance numeric(5,2) DEFAULT 0,
  theoretical_food_cost_pct numeric(5,2) DEFAULT 0,
  on_hand_amount numeric(12,2) DEFAULT 0,
  theoretical_variance numeric(5,2) DEFAULT 0,
  
  sage_food_sales_qtd numeric(12,2) DEFAULT 0,
  sage_fcost_qtd_pct numeric(5,2) DEFAULT 0,
  food_cost_ptd_pct numeric(5,2) DEFAULT 0,
  sage_sales_budget_qtd numeric(12,2) DEFAULT 0,
  fc_qtd_pct numeric(5,2) DEFAULT 0,
  qtd_variance_pct numeric(5,2) DEFAULT 0,
  usage_amount numeric(12,2) DEFAULT 0,
  ideal_usage_amount numeric(12,2) DEFAULT 0,
  cogs_qtd numeric(12,2) DEFAULT 0,
  food_sales_silverware numeric(12,2) DEFAULT 0,
  food_sales_oc numeric(12,2) DEFAULT 0,
  week_variance_amount numeric(12,2) DEFAULT 0,
  budget_food_sales_period numeric(12,2) DEFAULT 0,
  week_budget numeric(12,2) DEFAULT 0,
  qtd_variance_amount numeric(12,2) DEFAULT 0,
  
  labour_budget_pct numeric(5,2) DEFAULT 0,
  labour_cost_pct numeric(5,2) DEFAULT 0,
  lc_variance numeric(5,2) DEFAULT 0,
  sage_labour_budget_qtd_pct numeric(5,2) DEFAULT 0,
  sage_lcost_qtd_pct numeric(5,2) DEFAULT 0,
  labour_cost_ptd_pct numeric(5,2) DEFAULT 0,
  labour_qtd_pct numeric(5,2) DEFAULT 0,
  lab_ptd_var_amount numeric(12,2) DEFAULT 0,
  qtd_labour_variance_pct numeric(5,2) DEFAULT 0,
  labour_spent numeric(12,2) DEFAULT 0,
  overtime_amount numeric(12,2) DEFAULT 0,
  lab_qtd_var_amount numeric(12,2) DEFAULT 0,
  
  ebidta_budget_period_pct numeric(5,2) DEFAULT 0,
  ebidta_ptd_pct numeric(5,2) DEFAULT 0,
  ebidta_variance_pct numeric(5,2) DEFAULT 0,
  qsr_weekend_lunch_time text DEFAULT '',
  qsr_expo_time text DEFAULT '',
  teamshare_amount numeric(8,2) DEFAULT 0,
  
  petty_cash numeric(10,2) DEFAULT 0,
  waste_amount numeric(10,2) DEFAULT 0,
  last_audit_score_pct numeric(5,2) DEFAULT 0,
  boh_promo_amount numeric(10,2) DEFAULT 0,
  promo_ptd numeric(10,2) DEFAULT 0,
  promo_qtd numeric(10,2) DEFAULT 0,
  weeks_remaining_in_qtr integer DEFAULT 0,
  sous_vac_days integer DEFAULT 0,
  
  food_cost_summary text DEFAULT '',
  labour_summary text DEFAULT '',
  boh_promo_summary text DEFAULT '',
  notes text DEFAULT '',
  action_plan_summary text DEFAULT '',
  rm_issues_cleaning_focus text DEFAULT '',
  
  ideal_cooks integer DEFAULT 0,
  current_cooks integer DEFAULT 0,
  ideal_prep integer DEFAULT 0,
  current_prep integer DEFAULT 0,
  ideal_dish integer DEFAULT 0,
  current_dish integer DEFAULT 0,
  ideal_other integer DEFAULT 0,
  current_other integer DEFAULT 0,
  hiring_notes text DEFAULT '',
  tm_mots_of_note text DEFAULT '',
  development_path_updates text DEFAULT '',
  
  feature_items jsonb DEFAULT '[]'::jsonb,
  hires jsonb DEFAULT '[]'::jsonb,
  terminated jsonb DEFAULT '[]'::jsonb,
  
  UNIQUE(location_id, fiscal_year, period_number, week_number)
);

ALTER TABLE weekly_chef_summary ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view summaries for their location"
  ON weekly_chef_summary
  FOR SELECT
  TO authenticated
  USING (
    location_id IN (
      SELECT l.id FROM locations l
      INNER JOIN public.users u ON u.restaurant = l.name
      WHERE u.id = auth.uid()
    )
  );

CREATE POLICY "Users can create summaries for their location"
  ON weekly_chef_summary
  FOR INSERT
  TO authenticated
  WITH CHECK (
    location_id IN (
      SELECT l.id FROM locations l
      INNER JOIN public.users u ON u.restaurant = l.name
      WHERE u.id = auth.uid()
    )
  );

CREATE POLICY "Users can update summaries for their location"
  ON weekly_chef_summary
  FOR UPDATE
  TO authenticated
  USING (
    location_id IN (
      SELECT l.id FROM locations l
      INNER JOIN public.users u ON u.restaurant = l.name
      WHERE u.id = auth.uid()
    )
  )
  WITH CHECK (
    location_id IN (
      SELECT l.id FROM locations l
      INNER JOIN public.users u ON u.restaurant = l.name
      WHERE u.id = auth.uid()
    )
  );

CREATE POLICY "Admins can view all summaries"
  ON weekly_chef_summary
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE INDEX IF NOT EXISTS idx_weekly_chef_summary_location ON weekly_chef_summary(location_id);
CREATE INDEX IF NOT EXISTS idx_weekly_chef_summary_period ON weekly_chef_summary(fiscal_year, period_number, week_number);
