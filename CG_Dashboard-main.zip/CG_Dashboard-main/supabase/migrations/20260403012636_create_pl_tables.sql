/*
  # Restaurant P&L Data Management System

  1. New Tables
    - `locations`
      - `id` (uuid, primary key)
      - `name` (text) - Restaurant name
      - `code` (text) - Unique identifier code
      - `created_at` (timestamp)
    
    - `pl_uploads`
      - `id` (uuid, primary key)
      - `location_id` (uuid, foreign key to locations)
      - `week_ending_date` (date) - Sunday close date
      - `uploaded_at` (timestamp) - When the file was uploaded
      - `filename` (text) - Original CSV filename
      - `status` (text) - processing status
      - `created_at` (timestamp)
    
    - `pl_line_items`
      - `id` (uuid, primary key)
      - `upload_id` (uuid, foreign key to pl_uploads)
      - `location_id` (uuid, foreign key to locations)
      - `week_ending_date` (date) - Denormalized for easier querying
      - `line_item_name` (text) - One of the 9 tracked metrics
      - `current_actual` (numeric) - Current period actual amount
      - `current_actual_pct` (numeric) - Current period actual percentage
      - `current_budget` (numeric) - Current period budget amount
      - `current_budget_pct` (numeric) - Current period budget percentage
      - `prior_year` (numeric) - Prior year period amount
      - `prior_year_pct` (numeric) - Prior year period percentage
      - `ytd_actual` (numeric) - Year-to-date actual amount
      - `ytd_actual_pct` (numeric) - Year-to-date actual percentage
      - `ytd_budget` (numeric) - Year-to-date budget amount
      - `ytd_budget_pct` (numeric) - Year-to-date budget percentage
      - `prior_ytd` (numeric) - Prior year-to-date amount
      - `prior_ytd_pct` (numeric) - Prior year-to-date percentage
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read and write data
    
  3. Indexes
    - Add indexes for common query patterns
*/

-- Create locations table
CREATE TABLE IF NOT EXISTS locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create pl_uploads table
CREATE TABLE IF NOT EXISTS pl_uploads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  week_ending_date date NOT NULL,
  uploaded_at timestamptz DEFAULT now(),
  filename text NOT NULL,
  status text DEFAULT 'completed',
  created_at timestamptz DEFAULT now(),
  UNIQUE(location_id, week_ending_date)
);

-- Create pl_line_items table
CREATE TABLE IF NOT EXISTS pl_line_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  upload_id uuid NOT NULL REFERENCES pl_uploads(id) ON DELETE CASCADE,
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  week_ending_date date NOT NULL,
  line_item_name text NOT NULL,
  current_actual numeric,
  current_actual_pct numeric,
  current_budget numeric,
  current_budget_pct numeric,
  prior_year numeric,
  prior_year_pct numeric,
  ytd_actual numeric,
  ytd_actual_pct numeric,
  ytd_budget numeric,
  ytd_budget_pct numeric,
  prior_ytd numeric,
  prior_ytd_pct numeric,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE pl_uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE pl_line_items ENABLE ROW LEVEL SECURITY;

-- Create policies for locations
CREATE POLICY "Anyone can read locations"
  ON locations FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert locations"
  ON locations FOR INSERT
  TO public
  WITH CHECK (true);

-- Create policies for pl_uploads
CREATE POLICY "Anyone can read pl_uploads"
  ON pl_uploads FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert pl_uploads"
  ON pl_uploads FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update pl_uploads"
  ON pl_uploads FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete pl_uploads"
  ON pl_uploads FOR DELETE
  TO public
  USING (true);

-- Create policies for pl_line_items
CREATE POLICY "Anyone can read pl_line_items"
  ON pl_line_items FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert pl_line_items"
  ON pl_line_items FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can delete pl_line_items"
  ON pl_line_items FOR DELETE
  TO public
  USING (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_pl_uploads_location_date 
  ON pl_uploads(location_id, week_ending_date DESC);

CREATE INDEX IF NOT EXISTS idx_pl_line_items_location_date 
  ON pl_line_items(location_id, week_ending_date DESC);

CREATE INDEX IF NOT EXISTS idx_pl_line_items_upload 
  ON pl_line_items(upload_id);

-- Insert the 16 restaurant locations
INSERT INTO locations (name, code) VALUES
  ('Beertown Barrie', 'BARRIE'),
  ('Beertown Burlington', 'BURLINGTON'),
  ('Beertown Etobicoke', 'ETOBICOKE'),
  ('Beertown Hamilton', 'HAMILTON'),
  ('Beertown King West', 'KINGWEST'),
  ('Beertown London', 'LONDON'),
  ('Beertown Markham', 'MARKHAM'),
  ('Beertown Mississauga', 'MISSISSAUGA'),
  ('Beertown Oakville', 'OAKVILLE'),
  ('Beertown Ottawa', 'OTTAWA'),
  ('Beertown Pickering', 'PICKERING'),
  ('Beertown Scarborough', 'SCARBOROUGH'),
  ('Beertown Vaughan', 'VAUGHAN'),
  ('Beertown Waterloo', 'WATERLOO'),
  ('Beertown Whitby', 'WHITBY'),
  ('Beertown York', 'YORK')
ON CONFLICT (code) DO NOTHING;