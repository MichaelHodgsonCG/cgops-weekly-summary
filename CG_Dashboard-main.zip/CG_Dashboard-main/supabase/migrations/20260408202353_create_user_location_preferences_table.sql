/*
  # Create user_location_preferences table

  Stores per-user location preferences for filtering views.
  Users can opt-in to a set of preferred locations; views then
  offer a toggle to show only those locations.

  1. New Tables
    - `user_location_preferences`
      - `id` (uuid, primary key)
      - `user_id` (text) - matches the custom auth user id
      - `location_name` (text) - the preferred location name
      - `created_at` (timestamptz)

  2. Constraints
    - UNIQUE on (user_id, location_name) to prevent duplicates

  3. Security
    - Enable RLS
    - Allow anyone to read/insert/delete (matches existing permissive pattern)
*/

CREATE TABLE IF NOT EXISTS user_location_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  location_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE (user_id, location_name)
);

ALTER TABLE user_location_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view location preferences"
  ON user_location_preferences FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert location preferences"
  ON user_location_preferences FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can delete location preferences"
  ON user_location_preferences FOR DELETE
  USING (true);
