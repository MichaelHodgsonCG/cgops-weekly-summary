/*
  # Add "Need to Save" fields to weekly_chef_summary

  1. Changes
    - `weekly_chef_summary` table gets 4 new columns:
      - `fc_need_save_per_week` (numeric) - Food cost need-to-save per week (E26)
      - `fc_need_save_per_day` (numeric) - Food cost need-to-save per day (F26)
      - `labour_need_save_per_week` (numeric) - Labour need-to-save per week (E29)
      - `labour_need_save_per_day` (numeric) - Labour need-to-save per day (F29)

  2. Notes
    - All new columns default to 0
    - No destructive changes
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'weekly_chef_summary' AND column_name = 'fc_need_save_per_week'
  ) THEN
    ALTER TABLE weekly_chef_summary ADD COLUMN fc_need_save_per_week numeric(12,2) DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'weekly_chef_summary' AND column_name = 'fc_need_save_per_day'
  ) THEN
    ALTER TABLE weekly_chef_summary ADD COLUMN fc_need_save_per_day numeric(12,2) DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'weekly_chef_summary' AND column_name = 'labour_need_save_per_week'
  ) THEN
    ALTER TABLE weekly_chef_summary ADD COLUMN labour_need_save_per_week numeric(12,2) DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'weekly_chef_summary' AND column_name = 'labour_need_save_per_day'
  ) THEN
    ALTER TABLE weekly_chef_summary ADD COLUMN labour_need_save_per_day numeric(12,2) DEFAULT 0;
  END IF;
END $$;
