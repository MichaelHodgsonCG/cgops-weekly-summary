/*
  # Fix Roles Table RLS Policies for Anonymous Access

  1. Changes
    - Drop existing restrictive RLS policies that require authentication
    - Add new policies that allow anonymous access for reading, creating, and deleting roles
    - This matches the app's authentication pattern which uses custom PIN-based auth

  2. Security Notes
    - The app uses a custom authentication system (not Supabase auth)
    - Admin role checking happens in the application layer
    - Anonymous access is required for the Supabase client to work with this table
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Authenticated users can read roles" ON roles;
DROP POLICY IF EXISTS "Authenticated users can create roles" ON roles;
DROP POLICY IF EXISTS "Authenticated users can delete roles" ON roles;

-- Allow anonymous users to read roles
CREATE POLICY "Allow public read access to roles"
  ON roles
  FOR SELECT
  TO anon
  USING (true);

-- Allow anonymous users to create roles
CREATE POLICY "Allow public insert access to roles"
  ON roles
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anonymous users to delete roles
CREATE POLICY "Allow public delete access to roles"
  ON roles
  FOR DELETE
  TO anon
  USING (true);