/*
  # Add DELETE policies for SLP tables

  1. Changes
    - Add DELETE policy for slp_reports
    - Add DELETE policy for slp_sales_data
    - Add DELETE policy for slp_labor_data
    - Add DELETE policy for slp_promo_data

  2. Security
    - Policies allow authenticated users to delete SLP data
    - Cascade deletes will automatically handle related records
*/

-- Add delete policy for slp_reports
CREATE POLICY "Authenticated users can delete SLP reports"
  ON slp_reports FOR DELETE
  TO authenticated
  USING (true);

-- Add delete policy for slp_sales_data
CREATE POLICY "Authenticated users can delete SLP sales data"
  ON slp_sales_data FOR DELETE
  TO authenticated
  USING (true);

-- Add delete policy for slp_labor_data
CREATE POLICY "Authenticated users can delete SLP labor data"
  ON slp_labor_data FOR DELETE
  TO authenticated
  USING (true);

-- Add delete policy for slp_promo_data
CREATE POLICY "Authenticated users can delete SLP promo data"
  ON slp_promo_data FOR DELETE
  TO authenticated
  USING (true);