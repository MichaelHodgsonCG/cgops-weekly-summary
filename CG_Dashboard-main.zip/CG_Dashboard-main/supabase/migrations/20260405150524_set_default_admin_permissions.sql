/*
  # Set default permission settings

  1. Changes
    - Remove all existing role permissions
    - Grant all permissions to the Admin role
    - All other roles (HQ, Manager, Chef, Staff) start with no permissions
  
  2. Security
    - Admin role gets full access to all features
    - Other roles must be explicitly granted permissions as needed
*/

-- Clear all existing role permissions
DELETE FROM role_permissions;

-- Grant all permissions to Admin role
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
  r.id as role_id,
  p.id as permission_id
FROM roles r
CROSS JOIN permissions p
WHERE LOWER(r.name) = 'admin'
ON CONFLICT DO NOTHING;
