/*
  # Create Fiscal Calendar Table

  1. New Tables
    - `fiscal_calendar`
      - `id` (uuid, primary key)
      - `fiscal_year` (integer) - The fiscal year
      - `period` (integer) - Period number (1-13)
      - `week` (integer) - Week number within period (1-4)
      - `start_date` (date) - Week start date
      - `end_date` (date) - Week end date
      - `is_current` (boolean) - Flag for current period/week
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  
  2. Security
    - Enable RLS on `fiscal_calendar` table
    - Add policy for authenticated users to read all records
    - Add policy for authenticated users with admin role to manage records
  
  3. Indexes
    - Add index on fiscal_year, period, week for efficient lookups
    - Add index on start_date and end_date for date range queries
    - Add unique constraint on fiscal_year, period, week combination
*/

CREATE TABLE IF NOT EXISTS fiscal_calendar (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fiscal_year integer NOT NULL,
  period integer NOT NULL CHECK (period >= 1 AND period <= 13),
  week integer NOT NULL CHECK (week >= 1 AND week <= 4),
  start_date date NOT NULL,
  end_date date NOT NULL,
  is_current boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(fiscal_year, period, week)
);

-- Add indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_fiscal_calendar_year_period_week 
  ON fiscal_calendar(fiscal_year, period, week);

CREATE INDEX IF NOT EXISTS idx_fiscal_calendar_dates 
  ON fiscal_calendar(start_date, end_date);

CREATE INDEX IF NOT EXISTS idx_fiscal_calendar_current 
  ON fiscal_calendar(is_current) WHERE is_current = true;

-- Enable RLS
ALTER TABLE fiscal_calendar ENABLE ROW LEVEL SECURITY;

-- Allow all authenticated users to read fiscal calendar
CREATE POLICY "Anyone can read fiscal calendar"
  ON fiscal_calendar
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow anonymous users to read fiscal calendar (for public dashboards)
CREATE POLICY "Public can read fiscal calendar"
  ON fiscal_calendar
  FOR SELECT
  TO anon
  USING (true);

-- Allow authenticated users to insert fiscal calendar entries
CREATE POLICY "Authenticated users can insert fiscal calendar"
  ON fiscal_calendar
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow authenticated users to update fiscal calendar entries
CREATE POLICY "Authenticated users can update fiscal calendar"
  ON fiscal_calendar
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Allow authenticated users to delete fiscal calendar entries
CREATE POLICY "Authenticated users can delete fiscal calendar"
  ON fiscal_calendar
  FOR DELETE
  TO authenticated
  USING (true);

-- Create a function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_fiscal_calendar_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_fiscal_calendar_updated_at
  BEFORE UPDATE ON fiscal_calendar
  FOR EACH ROW
  EXECUTE FUNCTION update_fiscal_calendar_updated_at();
